package com.almona.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
