# Changelog

## [1.0.0] - 2024-08-17

### Added
- Initial release
- Morning and Evening Dhikr
- Smart reminders
- Works offline
- Dark theme
- Favorite dhikr
- Search functionality
- Arabic and English support
- Dhikr counter
- Today's wird tracking
