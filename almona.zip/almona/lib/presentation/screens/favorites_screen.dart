import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:almona/core/theme/app_theme.dart';
import 'package:almona/core/services/favorites_service.dart';
import 'package:almona/data/models/favorite_model.dart';
import 'package:almona/presentation/screens/adhkar_screen.dart';
import 'package:almona/core/localization/app_localizations.dart';

class FavoritesScreen extends StatefulWidget {
  const FavoritesScreen({super.key});

  @override
  State<FavoritesScreen> createState() => _FavoritesScreenState();
}

class _FavoritesScreenState extends State<FavoritesScreen> {
  List<FavoriteModel> _favorites = [];

  @override
  void initState() {
    super.initState();
    _loadFavorites();
  }

  void _loadFavorites() {
    setState(() {
      _favorites = FavoritesService.getFavorites();
    });
  }

  void _removeFavorite(FavoriteModel favorite) {
    final box = FavoritesService.box;
    final allFavorites = FavoritesService.getFavorites();
    final index = allFavorites.indexWhere((f) => f.id == favorite.id);
    if (index != -1) {
      final key = box.keyAt(index);
      box.delete(key);
      _loadFavorites();
    }
  }

  @override
  Widget build(BuildContext context) {
    final localizations = AppLocalizations.of(context);
    
    return Scaffold(
      backgroundColor: AppTheme.deepBlack,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Row(
          children: [
            Icon(
              Icons.favorite_rounded,
              color: AppTheme.emerald,
              size: 28,
            ),
            const SizedBox(width: 12),
            Text(
              localizations?.favorites ?? 'المفضلة',
              style: GoogleFonts.cairo(
                color: AppTheme.softWhite,
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        actions: [
          if (_favorites.isNotEmpty)
            IconButton(
              icon: Icon(
                Icons.delete_outline,
                color: AppTheme.mutedText.withOpacity(0.3),
              ),
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                    backgroundColor: AppTheme.obsidian,
                    title: Text(
                      localizations?.deleteAll ?? 'حذف الكل',
                      style: TextStyle(color: AppTheme.softWhite),
                    ),
                    content: Text(
                      localizations?.deleteAllConfirm ?? 'هل أنت متأكد من حذف جميع الأذكار من المفضلة؟',
                      style: TextStyle(color: AppTheme.mutedText),
                    ),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: Text(
                          localizations?.cancel ?? 'إلغاء',
                          style: TextStyle(color: AppTheme.mutedText),
                        ),
                      ),
                      TextButton(
                        onPressed: () {
                          FavoritesService.clearFavorites();
                          _loadFavorites();
                          Navigator.pop(context);
                        },
                        child: Text(
                          localizations?.delete ?? 'حذف',
                          style: TextStyle(color: Colors.red),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
        ],
      ),
      body: _favorites.isEmpty ? _buildEmptyState(localizations) : _buildFavoritesList(),
    );
  }

  Widget _buildEmptyState(AppLocalizations? localizations) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Stack(
            alignment: Alignment.center,
            children: [
              Container(
                width: 120,
                height: 120,
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    colors: [
                      AppTheme.emerald.withOpacity(0.05),
                      Colors.transparent,
                    ],
                  ),
                  shape: BoxShape.circle,
                ),
              ),
              Icon(
                Icons.favorite_outline_rounded,
                size: 64,
                color: AppTheme.mutedText.withOpacity(0.1),
              ),
            ],
          ),
          const SizedBox(height: 24),
          Text(
            localizations?.saveFavorites ?? 'احفظ ما تحب ❤️',
            style: GoogleFonts.cairo(
              color: AppTheme.softWhite,
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            localizations?.addFavorites ?? 'أضف الأذكار التي تريد العودة إليها بسهولة',
            style: TextStyle(
              color: AppTheme.mutedText.withOpacity(0.6),
              fontSize: 15,
            ),
          ),
          const SizedBox(height: 32),
          GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const AdhkarScreen()),
              );
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              decoration: BoxDecoration(
                gradient: AppTheme.primaryGradient,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    Icons.favorite_rounded,
                    color: AppTheme.deepBlack,
                    size: 18,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    localizations?.exploreDhikr ?? 'استكشف الأذكار',
                    style: TextStyle(
                      color: AppTheme.deepBlack,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFavoritesList() {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _favorites.length,
      itemBuilder: (context, index) {
        final favorite = _favorites[index];
        return Container(
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                AppTheme.obsidian,
                AppTheme.deepBlack,
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: AppTheme.emerald.withOpacity(0.05),
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                favorite.arabicText,
                style: TextStyle(
                  color: AppTheme.softWhite,
                  fontSize: 16,
                  height: 1.6,
                  fontFamily: 'Uthmanic',
                ),
                textAlign: TextAlign.right,
                textDirection: TextDirection.rtl,
              ),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  GestureDetector(
                    onTap: () => _removeFavorite(favorite),
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.red.withOpacity(0.05),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Icon(
                        Icons.close_rounded,
                        color: Colors.red.withOpacity(0.3),
                        size: 18,
                      ),
                    ),
                  ),
                  Text(
                    favorite.source,
                    style: TextStyle(
                      color: AppTheme.mutedText.withOpacity(0.3),
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}
