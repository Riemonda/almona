import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:almona/core/theme/app_theme.dart';
import 'package:almona/core/services/notification_service.dart';
import 'package:almona/core/localization/app_localizations.dart';
import 'package:hive_flutter/hive_flutter.dart';

class NotificationSettingsScreen extends StatefulWidget {
  final Function(Locale)? onLocaleChange;
  
  const NotificationSettingsScreen({super.key, this.onLocaleChange});

  @override
  State<NotificationSettingsScreen> createState() => _NotificationSettingsScreenState();
}

class _NotificationSettingsScreenState extends State<NotificationSettingsScreen> {
  late Box settingsBox;
  bool _morningEnabled = true;
  bool _eveningEnabled = true;
  bool _middayEnabled = true;
  TimeOfDay _morningTime = const TimeOfDay(hour: 6, minute: 0);
  TimeOfDay _eveningTime = const TimeOfDay(hour: 18, minute: 0);
  TimeOfDay _middayTime = const TimeOfDay(hour: 12, minute: 0);
  String _currentLanguage = 'ar';

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  void _loadSettings() async {
    settingsBox = await Hive.openBox('settings');
    setState(() {
      _morningEnabled = settingsBox.get('morning_enabled', defaultValue: true);
      _eveningEnabled = settingsBox.get('evening_enabled', defaultValue: true);
      _middayEnabled = settingsBox.get('midday_enabled', defaultValue: true);
      _currentLanguage = settingsBox.get('language', defaultValue: 'ar');
      
      final morningHour = settingsBox.get('morning_hour', defaultValue: 6);
      final morningMinute = settingsBox.get('morning_minute', defaultValue: 0);
      _morningTime = TimeOfDay(hour: morningHour, minute: morningMinute);
      
      final eveningHour = settingsBox.get('evening_hour', defaultValue: 18);
      final eveningMinute = settingsBox.get('evening_minute', defaultValue: 0);
      _eveningTime = TimeOfDay(hour: eveningHour, minute: eveningMinute);
      
      final middayHour = settingsBox.get('midday_hour', defaultValue: 12);
      final middayMinute = settingsBox.get('midday_minute', defaultValue: 0);
      _middayTime = TimeOfDay(hour: middayHour, minute: middayMinute);
    });
  }

  void _saveSettings() {
    settingsBox.put('morning_enabled', _morningEnabled);
    settingsBox.put('evening_enabled', _eveningEnabled);
    settingsBox.put('midday_enabled', _middayEnabled);
    settingsBox.put('morning_hour', _morningTime.hour);
    settingsBox.put('morning_minute', _morningTime.minute);
    settingsBox.put('evening_hour', _eveningTime.hour);
    settingsBox.put('evening_minute', _eveningTime.minute);
    settingsBox.put('midday_hour', _middayTime.hour);
    settingsBox.put('midday_minute', _middayTime.minute);
    settingsBox.put('language', _currentLanguage);
    
    NotificationService.cancelAllReminders();
    if (_morningEnabled) NotificationService.scheduleMorningReminder();
    if (_eveningEnabled) NotificationService.scheduleEveningReminder();
    if (_middayEnabled) NotificationService.scheduleMiddayReminder();
    
    // تغيير اللغة
    if (widget.onLocaleChange != null) {
      widget.onLocaleChange!(Locale(_currentLanguage));
    }
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          _currentLanguage == 'ar' ? '✅ تم حفظ الإعدادات' : '✅ Settings saved',
        ),
        backgroundColor: AppTheme.emerald,
        duration: Duration(seconds: 2),
      ),
    );
    
    Navigator.pop(context);
  }

  void _changeLanguage(String language) {
    setState(() {
      _currentLanguage = language;
    });
  }

  Future<void> _selectTime(BuildContext context, String type) async {
    TimeOfDay? selectedTime;
    if (type == 'morning') {
      selectedTime = await showTimePicker(
        context: context,
        initialTime: _morningTime,
        builder: (context, child) {
          return Theme(
            data: ThemeData.dark().copyWith(
              colorScheme: ColorScheme.dark(
                primary: AppTheme.emerald,
                onPrimary: AppTheme.deepBlack,
              ),
            ),
            child: child!,
          );
        },
      );
      if (selectedTime != null) {
        setState(() {
          _morningTime = selectedTime!;
        });
      }
    } else if (type == 'evening') {
      selectedTime = await showTimePicker(
        context: context,
        initialTime: _eveningTime,
        builder: (context, child) {
          return Theme(
            data: ThemeData.dark().copyWith(
              colorScheme: ColorScheme.dark(
                primary: AppTheme.emerald,
                onPrimary: AppTheme.deepBlack,
              ),
            ),
            child: child!,
          );
        },
      );
      if (selectedTime != null) {
        setState(() {
          _eveningTime = selectedTime!;
        });
      }
    } else if (type == 'midday') {
      selectedTime = await showTimePicker(
        context: context,
        initialTime: _middayTime,
        builder: (context, child) {
          return Theme(
            data: ThemeData.dark().copyWith(
              colorScheme: ColorScheme.dark(
                primary: AppTheme.emerald,
                onPrimary: AppTheme.deepBlack,
              ),
            ),
            child: child!,
          );
        },
      );
      if (selectedTime != null) {
        setState(() {
          _middayTime = selectedTime!;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final localizations = AppLocalizations.of(context);
    final isArabic = _currentLanguage == 'ar';
    
    return Scaffold(
      backgroundColor: AppTheme.deepBlack,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text(
          localizations?.notificationSettings ?? 'إعدادات الإشعارات',
          style: GoogleFonts.cairo(
            color: AppTheme.softWhite,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          TextButton(
            onPressed: _saveSettings,
            child: Text(
              localizations?.save ?? 'حفظ',
              style: TextStyle(
                color: AppTheme.emerald,
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppTheme.obsidian,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: AppTheme.emerald.withOpacity(0.1),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  isArabic ? '🌍 اللغة' : '🌍 Language',
                  style: TextStyle(
                    color: AppTheme.softWhite,
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: GestureDetector(
                        onTap: () => _changeLanguage('ar'),
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          decoration: BoxDecoration(
                            color: _currentLanguage == 'ar'
                                ? AppTheme.emerald.withOpacity(0.15)
                                : AppTheme.mutedText.withOpacity(0.05),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: _currentLanguage == 'ar'
                                  ? AppTheme.emerald
                                  : AppTheme.mutedText.withOpacity(0.05),
                            ),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                '🇸🇦',
                                style: TextStyle(fontSize: 20),
                              ),
                              const SizedBox(width: 8),
                              Text(
                                'العربية',
                                style: TextStyle(
                                  color: _currentLanguage == 'ar'
                                      ? AppTheme.emerald
                                      : AppTheme.mutedText,
                                  fontSize: 14,
                                  fontWeight: _currentLanguage == 'ar'
                                      ? FontWeight.w600
                                      : FontWeight.normal,
                                ),
                              ),
                              if (_currentLanguage == 'ar') ...[
                                const SizedBox(width: 8),
                                Icon(
                                  Icons.check_circle_rounded,
                                  color: AppTheme.emerald,
                                  size: 16,
                                ),
                              ],
                            ],
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: GestureDetector(
                        onTap: () => _changeLanguage('en'),
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          decoration: BoxDecoration(
                            color: _currentLanguage == 'en'
                                ? AppTheme.emerald.withOpacity(0.15)
                                : AppTheme.mutedText.withOpacity(0.05),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: _currentLanguage == 'en'
                                  ? AppTheme.emerald
                                  : AppTheme.mutedText.withOpacity(0.05),
                            ),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                '🇬🇧',
                                style: TextStyle(fontSize: 20),
                              ),
                              const SizedBox(width: 8),
                              Text(
                                'English',
                                style: TextStyle(
                                  color: _currentLanguage == 'en'
                                      ? AppTheme.emerald
                                      : AppTheme.mutedText,
                                  fontSize: 14,
                                  fontWeight: _currentLanguage == 'en'
                                      ? FontWeight.w600
                                      : FontWeight.normal,
                                ),
                              ),
                              if (_currentLanguage == 'en') ...[
                                const SizedBox(width: 8),
                                Icon(
                                  Icons.check_circle_rounded,
                                  color: AppTheme.emerald,
                                  size: 16,
                                ),
                              ],
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  isArabic
                      ? 'اختر لغة التطبيق (سيتم التحديث فوراً)'
                      : 'Choose app language (will update instantly)',
                  style: TextStyle(
                    color: AppTheme.mutedText.withOpacity(0.3),
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),
          
          const SizedBox(height: 16),
          
          _buildNotificationItem(
            isArabic ? '🌅 أذكار الصباح' : '🌅 Morning Dhikr',
            isArabic ? 'تذكير يومي في الصباح' : 'Daily morning reminder',
            _morningEnabled,
            _morningTime,
            (value) => setState(() => _morningEnabled = value!),
            () => _selectTime(context, 'morning'),
            isArabic,
          ),
          const SizedBox(height: 12),
          _buildNotificationItem(
            isArabic ? '🌙 أذكار المساء' : '🌙 Evening Dhikr',
            isArabic ? 'تذكير يومي في المساء' : 'Daily evening reminder',
            _eveningEnabled,
            _eveningTime,
            (value) => setState(() => _eveningEnabled = value!),
            () => _selectTime(context, 'evening'),
            isArabic,
          ),
          const SizedBox(height: 12),
          _buildNotificationItem(
            isArabic ? '🤲 تذكير منتصف اليوم' : '🤲 Midday Reminder',
            isArabic ? 'تذكير في منتصف النهار' : 'Midday reminder',
            _middayEnabled,
            _middayTime,
            (value) => setState(() => _middayEnabled = value!),
            () => _selectTime(context, 'midday'),
            isArabic,
          ),
          const SizedBox(height: 24),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppTheme.obsidian,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: AppTheme.mutedText.withOpacity(0.05),
              ),
            ),
            child: Column(
              children: [
                Icon(
                  Icons.info_outline,
                  color: AppTheme.mutedText.withOpacity(0.3),
                  size: 24,
                ),
                const SizedBox(height: 8),
                Text(
                  isArabic
                      ? 'ستظهر الإشعارات حتى لو كان التطبيق مغلقاً'
                      : 'Notifications will appear even if the app is closed',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: AppTheme.mutedText.withOpacity(0.5),
                    fontSize: 13,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNotificationItem(
    String title,
    String subtitle,
    bool value,
    TimeOfDay time,
    Function(bool?) onChanged,
    VoidCallback onTimeTap,
    bool isArabic,
  ) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.obsidian,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: value ? AppTheme.emerald.withOpacity(0.1) : AppTheme.mutedText.withOpacity(0.05),
        ),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        color: value ? AppTheme.softWhite : AppTheme.mutedText.withOpacity(0.4),
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      subtitle,
                      style: TextStyle(
                        color: AppTheme.mutedText.withOpacity(0.3),
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              Switch(
                value: value,
                onChanged: onChanged,
                activeColor: AppTheme.emerald,
                inactiveThumbColor: AppTheme.mutedText.withOpacity(0.2),
              ),
            ],
          ),
          if (value) ...[
            const SizedBox(height: 8),
            GestureDetector(
              onTap: onTimeTap,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: AppTheme.emerald.withOpacity(0.05),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: AppTheme.emerald.withOpacity(0.1),
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.access_time_rounded,
                      color: AppTheme.emerald,
                      size: 16,
                    ),
                    const SizedBox(width: 6),
                    Text(
                      time.format(context),
                      style: TextStyle(
                        color: AppTheme.emerald,
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(width: 6),
                    Icon(
                      Icons.edit_outlined,
                      color: AppTheme.emerald.withOpacity(0.3),
                      size: 14,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
