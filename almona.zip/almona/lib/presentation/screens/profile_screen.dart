import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:almona/core/theme/app_theme.dart';
import 'package:almona/presentation/screens/stats_screen.dart';
import 'package:almona/core/localization/app_localizations.dart';
import 'package:hive_flutter/hive_flutter.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  int _todayDhikrCount = 0;

  @override
  void initState() {
    super.initState();
    _loadStats();
  }

  void _loadStats() async {
    final statsBox = await Hive.openBox('stats');
    setState(() {
      _todayDhikrCount = statsBox.get('today_dhikr_count', defaultValue: 0);
    });
  }

  @override
  Widget build(BuildContext context) {
    final localizations = AppLocalizations.of(context);
    final now = DateTime.now();
    final dayOfMonth = now.day;
    
    final bool morningDone = _todayDhikrCount >= 1;
    final bool eveningDone = _todayDhikrCount >= 2;
    final bool sleepDone = _todayDhikrCount >= 3;
    
    final List<Map<String, String>> ayahs = [
      {'text': '﴿وَالذَّاكِرِينَ اللَّهَ كَثِيرًا وَالذَّاكِرَاتِ أَعَدَّ اللَّهُ لَهُم مَّغْفِرَةً وَأَجْرًا عَظِيمًا﴾', 'ref': 'الأحزاب: 35'},
      {'text': '﴿أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ﴾', 'ref': 'الرعد: 28'},
      {'text': '﴿وَلَذِكْرُ اللَّهِ أَكْبَرُ﴾', 'ref': 'العنكبوت: 45'},
      {'text': '﴿فَاذْكُرُونِي أَذْكُرْكُمْ وَاشْكُرُوا لِي وَلَا تَكْفُرُونِ﴾', 'ref': 'البقرة: 152'},
      {'text': '﴿يَا أَيُّهَا الَّذِينَ آمَنُوا اذْكُرُوا اللَّهَ ذِكْرًا كَثِيرًا﴾', 'ref': 'الأحزاب: 41'},
      {'text': '﴿رَبَّنَا وَلَا تُحَمِّلْنَا مَا لَا طَاقَةَ لَنَا بِهِ﴾', 'ref': 'البقرة: 286'},
      {'text': '﴿رَبَّنَا لَا تُزِغْ قُلُوبَنَا بَعْدَ إِذْ هَدَيْتَنَا﴾', 'ref': 'آل عمران: 8'},
      {'text': '﴿رَبَّنَا اغْفِرْ لِي وَلِوَالِدَيَّ وَلِلْمُؤْمِنِينَ يَوْمَ يَقُومُ الْحِسَابُ﴾', 'ref': 'إبراهيم: 41'},
      {'text': '﴿رَبِّ هَبْ لِي حُكْمًا وَأَلْحِقْنِي بِالصَّالِحِينَ﴾', 'ref': 'الشعراء: 83'},
      {'text': '﴿رَبِّ اشْرَحْ لِي صَدْرِي وَيَسِّرْ لِي أَمْرِي﴾', 'ref': 'طه: 25-26'},
      {'text': '﴿رَبِّ أَعُوذُ بِكَ مِنْ هَمَزَاتِ الشَّيَاطِينِ﴾', 'ref': 'المؤمنون: 97'},
      {'text': '﴿رَبَّنَا إِنَّنَا آمَنَّا فَاغْفِرْ لَنَا ذُنُوبَنَا وَقِنَا عَذَابَ النَّارِ﴾', 'ref': 'آل عمران: 16'},
      {'text': '﴿رَبَّنَا لَا تَجْعَلْنَا فِتْنَةً لِّلْقَوْمِ الظَّالِمِينَ﴾', 'ref': 'يونس: 85'},
      {'text': '﴿رَبَّنَا تَقَبَّلْ مِنَّا إِنَّكَ أَنتَ السَّمِيعُ الْعَلِيمُ﴾', 'ref': 'البقرة: 127'},
      {'text': '﴿رَبَّنَا أَفْرِغْ عَلَيْنَا صَبْرًا وَثَبِّتْ أَقْدَامَنَا﴾', 'ref': 'البقرة: 250'},
      {'text': '﴿رَبَّنَا ظَلَمْنَا أَنفُسَنَا وَإِن لَّمْ تَغْفِرْ لَنَا وَتَرْحَمْنَا لَنَكُونَنَّ مِنَ الْخَاسِرِينَ﴾', 'ref': 'الأعراف: 23'},
      {'text': '﴿رَبَّنَا هَبْ لَنَا مِنْ أَزْوَاجِنَا وَذُرِّيَّاتِنَا قُرَّةَ أَعْيُنٍ﴾', 'ref': 'الفرقان: 74'},
      {'text': '﴿رَبَّنَا عَلَيْكَ تَوَكَّلْنَا وَإِلَيْكَ أَنَبْنَا وَإِلَيْكَ الْمَصِيرُ﴾', 'ref': 'الممتحنة: 4'},
      {'text': '﴿رَبَّنَا آتِنَا مِن لَّدُنكَ رَحْمَةً وَهَيِّئْ لَنَا مِنْ أَمْرِنَا رَشَدًا﴾', 'ref': 'الكهف: 10'},
      {'text': '﴿رَبَّنَا أَرِنَا الَّذَيْنِ أَضَلَّانَا مِنَ الْجِنِّ وَالْإِنسِ﴾', 'ref': 'فصلت: 29'},
      {'text': '﴿رَبَّنَا آمَنَّا بِمَا أَنزَلْتَ وَاتَّبَعْنَا الرَّسُولَ﴾', 'ref': 'آل عمران: 53'},
      {'text': '﴿رَبَّنَا اغْفِرْ لَنَا وَلِإِخْوَانِنَا الَّذِينَ سَبَقُونَا بِالْإِيمَانِ﴾', 'ref': 'الحشر: 10'},
      {'text': '﴿رَبَّنَا لَا تَجْعَلْنَا مَعَ الْقَوْمِ الظَّالِمِينَ﴾', 'ref': 'الأعراف: 47'},
      {'text': '﴿رَبَّنَا إِنَّنَا آمَنَّا فَاغْفِرْ لَنَا وَعَذِّبْنَا عَذَابَ النَّارِ﴾', 'ref': 'آل عمران: 16'},
      {'text': '﴿رَبَّنَا إِنَّكَ جَامِعُ النَّاسِ لِيَوْمٍ لَّا رَيْبَ فِيهِ﴾', 'ref': 'آل عمران: 9'},
      {'text': '﴿رَبَّنَا إِنَّنَا سَمِعْنَا مُنَادِيًا يُنَادِي لِلْإِيمَانِ﴾', 'ref': 'آل عمران: 193'},
      {'text': '﴿رَبَّنَا لَا تُؤَاخِذْنَا إِن نَّسِينَا أَوْ أَخْطَأْنَا﴾', 'ref': 'البقرة: 286'},
      {'text': '﴿رَبَّنَا وَلَا تَحْمِلْ عَلَيْنَا إِصْرًا كَمَا حَمَلْتَهُ عَلَى الَّذِينَ مِن قَبْلِنَا﴾', 'ref': 'البقرة: 286'},
      {'text': '﴿رَبَّنَا وَاعْفُ عَنَّا وَاغْفِرْ لَنَا وَارْحَمْنَا﴾', 'ref': 'البقرة: 286'},
      {'text': '﴿رَبَّنَا أَنْتَ وَلِيُّنَا فَاغْفِرْ لَنَا وَارْحَمْنَا﴾', 'ref': 'الأعراف: 155'},
    ];
    
    final ayahIndex = (dayOfMonth - 1) % ayahs.length;
    final selectedAyah = ayahs[ayahIndex];
    
    return Scaffold(
      backgroundColor: AppTheme.deepBlack,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text(
          localizations?.myWird ?? 'ورد اليوم',
          style: GoogleFonts.cairo(
            color: AppTheme.softWhite,
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.bar_chart_outlined, color: AppTheme.mutedText),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const StatsScreen()),
              );
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    AppTheme.emerald.withOpacity(0.08),
                    Colors.transparent,
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: AppTheme.emerald.withOpacity(0.05),
                ),
              ),
              child: Row(
                children: [
                  Container(
                    width: 60,
                    height: 60,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: AppTheme.emerald.withOpacity(0.2),
                        width: 2,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: AppTheme.emerald.withOpacity(0.1),
                          blurRadius: 10,
                        ),
                      ],
                    ),
                    child: ClipOval(
                      child: Image.asset(
                        'assets/images/almona.png',
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) {
                          return Container(
                            color: AppTheme.emerald.withOpacity(0.1),
                            child: Icon(
                              Icons.person,
                              color: AppTheme.emerald,
                              size: 30,
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          localizations?.keepRemembrance ?? 'حافظ على ذكر الله',
                          style: GoogleFonts.cairo(
                            color: AppTheme.softWhite,
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          localizations?.dailyWirdKey ?? 'وردك اليومي هو مفتاح السكينة',
                          style: TextStyle(
                            color: AppTheme.mutedText,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            _buildProgressItem(
              localizations?.morning ?? '🌅 أذكار الصباح',
              morningDone,
              localizations,
            ),
            const SizedBox(height: 12),
            _buildProgressItem(
              localizations?.evening ?? '🌙 أذكار المساء',
              eveningDone,
              localizations,
            ),
            const SizedBox(height: 12),
            _buildProgressItem(
              localizations?.sleep ?? '💤 أذكار النوم',
              sleepDone,
              localizations,
            ),
            const SizedBox(height: 24),
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    AppTheme.emerald.withOpacity(0.05),
                    AppTheme.deepBlack,
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: AppTheme.emerald.withOpacity(0.05),
                ),
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Icon(
                        Icons.auto_awesome,
                        color: AppTheme.emerald.withOpacity(0.3),
                        size: 16,
                      ),
                      const SizedBox(width: 6),
                      Text(
                        'آية اليوم (${now.day}/${now.month})',
                        style: TextStyle(
                          color: AppTheme.mutedText.withOpacity(0.4),
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text(
                    selectedAyah['text']!,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: AppTheme.softWhite,
                      fontSize: 18,
                      height: 2.0,
                      fontFamily: 'Uthmanic',
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    selectedAyah['ref']!,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: AppTheme.mutedText.withOpacity(0.4),
                      fontSize: 13,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProgressItem(String title, bool isCompleted, AppLocalizations? localizations) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.obsidian,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isCompleted 
              ? AppTheme.emerald.withOpacity(0.2) 
              : AppTheme.mutedText.withOpacity(0.05),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: isCompleted 
                  ? AppTheme.emerald.withOpacity(0.15) 
                  : AppTheme.mutedText.withOpacity(0.05),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              isCompleted ? '✅ تم' : '⬜ لم يقرأ بعد',
              style: TextStyle(
                color: isCompleted ? AppTheme.emerald : AppTheme.mutedText.withOpacity(0.5),
                fontSize: 13,
                fontWeight: isCompleted ? FontWeight.w600 : FontWeight.normal,
              ),
            ),
          ),
          Text(
            title,
            style: GoogleFonts.cairo(
              color: isCompleted ? AppTheme.softWhite : AppTheme.mutedText.withOpacity(0.5),
              fontSize: 15,
              fontWeight: isCompleted ? FontWeight.w600 : FontWeight.normal,
            ),
          ),
        ],
      ),
    );
  }
}
