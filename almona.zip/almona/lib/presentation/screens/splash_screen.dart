import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:almona/core/theme/app_theme.dart';
import 'package:almona/presentation/screens/home_screen.dart';

class SplashScreen extends StatefulWidget {
  final Function(Locale) onLocaleChange;
  
  const SplashScreen({super.key, required this.onLocaleChange});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _fadeInAnimation;
  late Animation<double> _scaleAnimation;
  late Animation<double> _glowPulseAnimation;
  late Animation<Offset> _slideUpAnimation;

  @override
  void initState() {
    super.initState();
    
    _controller = AnimationController(
      duration: const Duration(milliseconds: 3000),
      vsync: this,
    );
    
    _fadeInAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _controller, curve: const Interval(0.0, 0.6, curve: Curves.easeOut)),
    );
    
    _scaleAnimation = Tween<double>(begin: 0.7, end: 1.0).animate(
      CurvedAnimation(parent: _controller, curve: const Interval(0.0, 0.5, curve: Curves.easeOutBack)),
    );
    
    _glowPulseAnimation = Tween<double>(begin: 0.3, end: 1.0).animate(
      CurvedAnimation(parent: _controller, curve: const Interval(0.2, 0.8, curve: Curves.easeInOut)),
    );
    
    _slideUpAnimation = Tween<Offset>(begin: const Offset(0, 0.3), end: Offset.zero).animate(
      CurvedAnimation(parent: _controller, curve: const Interval(0.3, 0.7, curve: Curves.easeOut)),
    );
    
    _controller.forward();
    
    // مدة الشاشة 4 ثوان
    Future.delayed(const Duration(seconds: 4), () {
      if (mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => HomeScreen(
              onLocaleChange: widget.onLocaleChange,
            ),
          ),
        );
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.deepBlack,
      body: Container(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: const Alignment(0, -0.2),
            radius: 1.2,
            colors: [
              AppTheme.emerald.withOpacity(0.08),
              AppTheme.deepBlack,
              AppTheme.deepBlack,
            ],
            stops: const [0.0, 0.5, 1.0],
          ),
        ),
        child: Stack(
          children: [
            ..._buildAnimatedStars(),
            Positioned(
              top: MediaQuery.of(context).size.height * 0.25,
              left: 0,
              right: 0,
              child: AnimatedBuilder(
                animation: _glowPulseAnimation,
                builder: (context, child) {
                  return Container(
                    height: 300,
                    decoration: BoxDecoration(
                      gradient: RadialGradient(
                        center: Alignment.center,
                        radius: 0.6,
                        colors: [
                          AppTheme.emerald.withOpacity(0.06 * _glowPulseAnimation.value),
                          Colors.transparent,
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
            Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  AnimatedBuilder(
                    animation: _controller,
                    builder: (context, child) {
                      return Opacity(
                        opacity: _fadeInAnimation.value,
                        child: Transform.scale(
                          scale: _scaleAnimation.value,
                          child: Column(
                            children: [
                              Stack(
                                alignment: Alignment.center,
                                children: [
                                  AnimatedContainer(
                                    duration: const Duration(milliseconds: 1500),
                                    width: 180 + 20 * _glowPulseAnimation.value,
                                    height: 180 + 20 * _glowPulseAnimation.value,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      gradient: RadialGradient(
                                        colors: [
                                          AppTheme.emerald.withOpacity(0.04 * _glowPulseAnimation.value),
                                          Colors.transparent,
                                        ],
                                        radius: 0.8,
                                      ),
                                    ),
                                  ),
                                  Container(
                                    width: 150,
                                    height: 150,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      gradient: RadialGradient(
                                        colors: [
                                          AppTheme.mintGlow.withOpacity(0.05 * _glowPulseAnimation.value),
                                          Colors.transparent,
                                        ],
                                        radius: 0.6,
                                      ),
                                    ),
                                  ),
                                  Container(
                                    width: 130,
                                    height: 130,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      boxShadow: [
                                        BoxShadow(
                                          color: AppTheme.emerald.withOpacity(0.25 * _glowPulseAnimation.value),
                                          blurRadius: 40,
                                          spreadRadius: 15,
                                        ),
                                        BoxShadow(
                                          color: AppTheme.mintGlow.withOpacity(0.08 * _glowPulseAnimation.value),
                                          blurRadius: 70,
                                          spreadRadius: 25,
                                        ),
                                      ],
                                    ),
                                    child: ClipOval(
                                      child: Image.asset(
                                        'assets/images/almona.png',
                                        fit: BoxFit.cover,
                                        errorBuilder: (context, error, stackTrace) {
                                          return Container(
                                            decoration: BoxDecoration(
                                              gradient: LinearGradient(
                                                colors: [AppTheme.emerald, AppTheme.jade, AppTheme.mintGlow],
                                                begin: Alignment.topLeft,
                                                end: Alignment.bottomRight,
                                              ),
                                              shape: BoxShape.circle,
                                            ),
                                            child: const Center(
                                              child: Text(
                                                'المنى',
                                                style: TextStyle(
                                                  color: Colors.black,
                                                  fontSize: 28,
                                                  fontWeight: FontWeight.bold,
                                                  letterSpacing: 2,
                                                ),
                                              ),
                                            ),
                                          );
                                        },
                                      ),
                                    ),
                                  ),
                                  Container(
                                    width: 136,
                                    height: 136,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      border: Border.all(
                                        color: AppTheme.emerald.withOpacity(0.08 * _glowPulseAnimation.value),
                                        width: 1.5,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 32),
                              Text(
                                'Almona',
                                style: GoogleFonts.cairo(
                                  color: AppTheme.softWhite,
                                  fontSize: 32,
                                  fontWeight: FontWeight.w300,
                                  letterSpacing: 6,
                                  shadows: [
                                    Shadow(
                                      color: AppTheme.emerald.withOpacity(0.1),
                                      blurRadius: 20,
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 12),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 6),
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [AppTheme.emerald.withOpacity(0.05), Colors.transparent],
                                    begin: Alignment.centerLeft,
                                    end: Alignment.centerRight,
                                  ),
                                  borderRadius: BorderRadius.circular(20),
                                  border: Border.all(
                                    color: AppTheme.emerald.withOpacity(0.05),
                                  ),
                                ),
                                child: Text(
                                  'رفيقك اليومي للذكر',
                                  style: TextStyle(
                                    color: AppTheme.mutedText,
                                    fontSize: 14,
                                    letterSpacing: 2,
                                    fontWeight: FontWeight.w300,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 60),
                  AnimatedBuilder(
                    animation: _controller,
                    builder: (context, child) {
                      return Opacity(
                        opacity: _fadeInAnimation.value,
                        child: SlideTransition(
                          position: _slideUpAnimation,
                          child: Container(
                            width: 120,
                            height: 2,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  Colors.transparent,
                                  AppTheme.emerald.withOpacity(0.3),
                                  AppTheme.mintGlow.withOpacity(0.5),
                                  AppTheme.emerald.withOpacity(0.3),
                                  Colors.transparent,
                                ],
                              ),
                              borderRadius: BorderRadius.circular(2),
                            ),
                            child: AnimatedBuilder(
                              animation: _controller,
                              builder: (context, child) {
                                return FractionallySizedBox(
                                  widthFactor: _controller.value,
                                  child: Container(
                                    decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                        colors: [AppTheme.emerald, AppTheme.mintGlow, AppTheme.jade],
                                      ),
                                      borderRadius: BorderRadius.circular(2),
                                      boxShadow: [
                                        BoxShadow(
                                          color: AppTheme.emerald.withOpacity(0.2),
                                          blurRadius: 10,
                                          spreadRadius: 2,
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
            Positioned(
              bottom: 30,
              left: 0,
              right: 0,
              child: Center(
                child: AnimatedBuilder(
                  animation: _controller,
                  builder: (context, child) {
                    return Opacity(
                      opacity: _fadeInAnimation.value * 0.3,
                      child: Text(
                        'Almona © 2026',
                        style: TextStyle(
                          color: AppTheme.mutedText,
                          fontSize: 11,
                          letterSpacing: 1,
                          fontWeight: FontWeight.w300,
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<Widget> _buildAnimatedStars() {
    final List<Widget> stars = [];
    final random = DateTime.now().millisecondsSinceEpoch % 1000;
    
    for (int i = 0; i < 25; i++) {
      final double x = ((i * 37 + random) % 100) / 100;
      final double y = ((i * 23 + random * 3) % 100) / 100;
      final double size = 1.5 + (i % 3) * 0.5;
      final double opacity = 0.1 + (i % 5) * 0.05;
      
      stars.add(
        Positioned(
          left: x * MediaQuery.of(context).size.width,
          top: y * MediaQuery.of(context).size.height,
          child: AnimatedBuilder(
            animation: _controller,
            builder: (context, child) {
              final double pulse = (0.5 + 0.5 * 
                  (i % 10) * (1 - _controller.value)) as double;
              return Container(
                width: size,
                height: size,
                decoration: BoxDecoration(
                  color: AppTheme.softWhite.withOpacity(opacity * pulse * 0.3),
                  shape: BoxShape.circle,
                ),
              );
            },
          ),
        ),
      );
    }
    return stars;
  }
}
