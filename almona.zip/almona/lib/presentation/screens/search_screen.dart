import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:almona/core/theme/app_theme.dart';
import 'package:almona/data/models/adhkar_model.dart';
import 'package:almona/core/services/azkar_service.dart';
import 'package:almona/presentation/screens/adhkar_screen.dart';
import 'package:almona/core/localization/app_localizations.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';
  bool _isFocused = false;
  List<AdhkarModel> _allAdhkar = [];
  List<AdhkarModel> _searchResults = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadAzkar();
  }

  Future<void> _loadAzkar() async {
    final azkar = await AzkarService.loadAzkar();
    setState(() {
      _allAdhkar = azkar;
      _isLoading = false;
    });
  }

  void _performSearch(String query) {
    setState(() {
      _searchQuery = query;
      if (query.isEmpty) {
        _searchResults = [];
      } else {
        _searchResults = _allAdhkar.where((adhkar) {
          return adhkar.arabicText.contains(query) ||
              adhkar.englishText.toLowerCase().contains(query.toLowerCase()) ||
              adhkar.category.contains(query) ||
              adhkar.source.contains(query);
        }).toList();
      }
    });
  }

  void _navigateToAdhkar(String category) {
    Navigator.push(context, MaterialPageRoute(builder: (context) => AdhkarScreen(initialCategory: category)));
  }

  @override
  Widget build(BuildContext context) {
    final localizations = AppLocalizations.of(context);
    
    return Scaffold(
      backgroundColor: AppTheme.deepBlack,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text(
          localizations?.search ?? 'البحث في الأذكار',
          style: GoogleFonts.cairo(color: AppTheme.softWhite, fontSize: 18, fontWeight: FontWeight.w500),
        ),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(valueColor: AlwaysStoppedAnimation(Color(0xFF00C896))))
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Focus(
                    onFocusChange: (focused) => setState(() => _isFocused = focused),
                    child: Container(
                      decoration: BoxDecoration(
                        color: AppTheme.obsidian,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: _isFocused ? AppTheme.emerald.withOpacity(0.3) : AppTheme.mutedText.withOpacity(0.05)),
                      ),
                      child: TextField(
                        controller: _searchController,
                        onChanged: _performSearch,
                        style: TextStyle(color: AppTheme.softWhite),
                        decoration: InputDecoration(
                          hintText: localizations?.searchDhikr ?? 'ابحث عن ذكر أو دعاء...',
                          hintStyle: TextStyle(color: AppTheme.mutedText.withOpacity(0.4)),
                          border: InputBorder.none,
                          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                          prefixIcon: Icon(Icons.search, color: AppTheme.mutedText.withOpacity(0.3), size: 20),
                          suffixIcon: _searchQuery.isNotEmpty
                              ? IconButton(
                                  icon: Icon(Icons.close, color: AppTheme.mutedText, size: 18),
                                  onPressed: () {
                                    _searchController.clear();
                                    _performSearch('');
                                  },
                                )
                              : null,
                        ),
                      ),
                    ),
                  ),
                ),
                Expanded(child: _buildContent(localizations)),
              ],
            ),
    );
  }

  Widget _buildContent(AppLocalizations? localizations) {
    if (_searchQuery.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.search_rounded, size: 48, color: AppTheme.mutedText.withOpacity(0.1)),
            const SizedBox(height: 16),
            Text(
              localizations?.whatLookingFor ?? 'ماذا تبحث عنه؟',
              style: TextStyle(color: AppTheme.softWhite.withOpacity(0.5), fontSize: 16),
            ),
            const SizedBox(height: 8),
            Text(
              localizations?.searchExample ?? 'ابحث عن أذكار الصباح، المساء، النوم...',
              style: TextStyle(color: AppTheme.mutedText.withOpacity(0.3), fontSize: 13),
            ),
            const SizedBox(height: 24),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              alignment: WrapAlignment.center,
              children: [
                _buildChip(localizations?.morning ?? 'الصباح', 'morning'),
                _buildChip(localizations?.evening ?? 'المساء', 'evening'),
                _buildChip(localizations?.sleep ?? 'النوم', 'sleep'),
                _buildChip(localizations?.travel ?? 'السفر', 'travel'),
                _buildChip(localizations?.afterPrayer ?? 'الصلاة', 'prayer'),
              ],
            ),
          ],
        ),
      );
    } else if (_searchResults.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.search_off, size: 48, color: AppTheme.mutedText.withOpacity(0.1)),
            const SizedBox(height: 16),
            Text(
              localizations?.noResults ?? 'لم نجد ما تبحث عنه',
              style: TextStyle(color: AppTheme.softWhite.withOpacity(0.5), fontSize: 16),
            ),
            const SizedBox(height: 8),
            Text(
              localizations?.tryOtherWords ?? 'جرّب كلمات أخرى',
              style: TextStyle(color: AppTheme.mutedText.withOpacity(0.3), fontSize: 13),
            ),
          ],
        ),
      );
    } else {
      return ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _searchResults.length,
        itemBuilder: (context, index) {
          final adhkar = _searchResults[index];
          return GestureDetector(
            onTap: () => _navigateToAdhkar(adhkar.category),
            child: Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppTheme.obsidian,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppTheme.mutedText.withOpacity(0.05)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(adhkar.arabicText, style: TextStyle(color: AppTheme.softWhite, fontSize: 15, height: 1.6), textAlign: TextAlign.right),
                  const SizedBox(height: 6),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('${adhkar.repetitions} مرات', style: TextStyle(color: AppTheme.mutedText.withOpacity(0.4), fontSize: 11)),
                      Text(adhkar.source, style: TextStyle(color: AppTheme.mutedText.withOpacity(0.3), fontSize: 11)),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      );
    }
  }

  Widget _buildChip(String label, String category) {
    return GestureDetector(
      onTap: () => _navigateToAdhkar(category),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        decoration: BoxDecoration(
          color: AppTheme.obsidian,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppTheme.mutedText.withOpacity(0.05)),
        ),
        child: Text(label, style: TextStyle(color: AppTheme.mutedText, fontSize: 12)),
      ),
    );
  }
}
