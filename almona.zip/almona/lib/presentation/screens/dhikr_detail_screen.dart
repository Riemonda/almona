import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:almona/core/theme/app_theme.dart';
import 'package:almona/data/models/adhkar_model.dart';
import 'package:almona/core/services/favorites_service.dart';
import 'package:almona/core/services/share_service.dart';
import 'package:almona/core/localization/app_localizations.dart';

class DhikrDetailScreen extends StatefulWidget {
  final AdhkarModel adhkar;

  const DhikrDetailScreen({super.key, required this.adhkar});

  @override
  State<DhikrDetailScreen> createState() => _DhikrDetailScreenState();
}

class _DhikrDetailScreenState extends State<DhikrDetailScreen> {
  int _currentCount = 0;
  bool _isCompleted = false;
  bool _isFavorite = false;
  bool _showEnglish = false;

  @override
  void initState() {
    super.initState();
    _isFavorite = FavoritesService.isFavorite(widget.adhkar);
  }

  void _incrementCounter() {
    if (_isCompleted) return;
    setState(() {
      _currentCount++;
      if (_currentCount >= widget.adhkar.repetitions) {
        _currentCount = widget.adhkar.repetitions;
        _isCompleted = true;
      }
    });
  }

  void _resetCounter() {
    setState(() {
      _currentCount = 0;
      _isCompleted = false;
    });
  }

  void _toggleFavorite() {
    FavoritesService.toggleFavorite(widget.adhkar);
    setState(() {
      _isFavorite = !_isFavorite;
    });
  }

  void _shareDhikr() {
    ShareService.shareDhikr(widget.adhkar);
  }

  @override
  Widget build(BuildContext context) {
    final localizations = AppLocalizations.of(context);
    
    return Scaffold(
      backgroundColor: AppTheme.deepBlack,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_rounded, color: AppTheme.softWhite),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          localizations?.translate('dhikr_detail') ?? 'تفاصيل الذكر',
          style: GoogleFonts.cairo(
            color: AppTheme.softWhite,
            fontSize: 18,
            fontWeight: FontWeight.w500,
          ),
        ),
        actions: [
          IconButton(
            icon: Icon(
              _isFavorite ? Icons.favorite_rounded : Icons.favorite_border_rounded,
              color: _isFavorite ? AppTheme.emerald : AppTheme.mutedText,
            ),
            onPressed: _toggleFavorite,
          ),
          IconButton(
            icon: Icon(Icons.share_outlined, color: AppTheme.mutedText),
            onPressed: _shareDhikr,
          ),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              // المصدر
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                decoration: BoxDecoration(
                  color: AppTheme.obsidian,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: AppTheme.emerald.withOpacity(0.05),
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.book_outlined, size: 14, color: AppTheme.mutedText.withOpacity(0.3)),
                        const SizedBox(width: 4),
                        Text(
                          widget.adhkar.source,
                          style: TextStyle(
                            color: AppTheme.mutedText.withOpacity(0.4),
                            fontSize: 12,
                          ),
                        ),
                        if (widget.adhkar.reference != null) ...[
                          const SizedBox(width: 4),
                          Text(
                            '(${widget.adhkar.reference})',
                            style: TextStyle(
                              color: AppTheme.mutedText.withOpacity(0.3),
                              fontSize: 11,
                            ),
                          ),
                        ],
                      ],
                    ),
                    GestureDetector(
                      onTap: () => setState(() => _showEnglish = !_showEnglish),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: AppTheme.emerald.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          _showEnglish ? 'عربي' : 'English',
                          style: TextStyle(
                            color: AppTheme.emerald,
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              // النص
              Expanded(
                child: Center(
                  child: SingleChildScrollView(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                AppTheme.obsidian,
                                AppTheme.deepBlack,
                              ],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                              color: AppTheme.emerald.withOpacity(0.05),
                            ),
                          ),
                          child: _showEnglish
                              ? Text(
                                  widget.adhkar.englishText,
                                  style: TextStyle(
                                    color: AppTheme.mutedText.withOpacity(0.8),
                                    fontSize: 16,
                                    height: 1.8,
                                  ),
                                  textAlign: TextAlign.center,
                                )
                              : Text(
                                  widget.adhkar.arabicText,
                                  style: TextStyle(
                                    color: AppTheme.softWhite,
                                    fontSize: 20,
                                    height: 2.0,
                                    fontFamily: 'Uthmanic',
                                  ),
                                  textAlign: TextAlign.center,
                                  textDirection: TextDirection.rtl,
                                ),
                        ),
                        const SizedBox(height: 10),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                          decoration: BoxDecoration(
                            color: AppTheme.emerald.withOpacity(0.05),
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.repeat_rounded,
                                color: AppTheme.emerald.withOpacity(0.3),
                                size: 14,
                              ),
                              const SizedBox(width: 4),
                              Text(
                                '${widget.adhkar.repetitions} ${localizations?.translate('times') ?? 'مرات'}',
                                style: TextStyle(
                                  color: AppTheme.mutedText.withOpacity(0.4),
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              // عداد التكرار
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      AppTheme.obsidian,
                      AppTheme.deepBlack,
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: _isCompleted
                        ? AppTheme.emerald.withOpacity(0.15)
                        : AppTheme.mutedText.withOpacity(0.05),
                  ),
                ),
                child: Column(
                  children: [
                    Stack(
                      children: [
                        Container(
                          height: 4,
                          decoration: BoxDecoration(
                            color: AppTheme.mutedText.withOpacity(0.05),
                            borderRadius: BorderRadius.circular(2),
                          ),
                          child: FractionallySizedBox(
                            widthFactor: _currentCount / widget.adhkar.repetitions,
                            child: Container(
                              decoration: BoxDecoration(
                                gradient: AppTheme.primaryGradient,
                                borderRadius: BorderRadius.circular(2),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          left: 0,
                          right: 0,
                          top: -12,
                          child: Center(
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
                              decoration: BoxDecoration(
                                color: AppTheme.obsidian,
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(
                                  color: _isCompleted
                                      ? AppTheme.emerald.withOpacity(0.2)
                                      : AppTheme.mutedText.withOpacity(0.05),
                                ),
                              ),
                              child: Text(
                                '$_currentCount / ${widget.adhkar.repetitions}',
                                style: TextStyle(
                                  color: _isCompleted ? AppTheme.emerald : AppTheme.softWhite,
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 24),
                    Row(
                      children: [
                        Expanded(
                          child: GestureDetector(
                            onTap: _isCompleted ? null : _incrementCounter,
                            child: Container(
                              padding: const EdgeInsets.symmetric(vertical: 12),
                              decoration: BoxDecoration(
                                gradient: _isCompleted
                                    ? null
                                    : AppTheme.primaryGradient,
                                color: _isCompleted
                                    ? AppTheme.mutedText.withOpacity(0.05)
                                    : null,
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                  color: _isCompleted
                                      ? AppTheme.mutedText.withOpacity(0.05)
                                      : AppTheme.emerald,
                                ),
                              ),
                              child: Center(
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(
                                      _isCompleted ? Icons.check_circle_rounded : Icons.add_rounded,
                                      color: _isCompleted ? AppTheme.mutedText : AppTheme.deepBlack,
                                      size: 20,
                                    ),
                                    const SizedBox(width: 6),
                                    Text(
                                      _isCompleted 
                                          ? (localizations?.translate('completed') ?? 'تم ✅')
                                          : (localizations?.translate('press_to_count') ?? 'اضغط للعد +'),
                                      style: TextStyle(
                                        color: _isCompleted ? AppTheme.mutedText : AppTheme.deepBlack,
                                        fontSize: 14,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                        if (_isCompleted) ...[
                          const SizedBox(width: 10),
                          GestureDetector(
                            onTap: _resetCounter,
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                              decoration: BoxDecoration(
                                color: AppTheme.mutedText.withOpacity(0.05),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                  color: AppTheme.mutedText.withOpacity(0.05),
                                ),
                              ),
                              child: Icon(
                                Icons.refresh_rounded,
                                color: AppTheme.mutedText.withOpacity(0.3),
                                size: 20,
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  decoration: BoxDecoration(
                    color: AppTheme.emerald.withOpacity(0.05),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: AppTheme.emerald.withOpacity(0.1),
                    ),
                  ),
                  child: Center(
                    child: Text(
                      localizations?.translate('back_to_dhikr') ?? 'العودة للأذكار',
                      style: TextStyle(
                        color: AppTheme.emerald,
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
