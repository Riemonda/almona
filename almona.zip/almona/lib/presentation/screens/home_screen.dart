import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:almona/core/theme/app_theme.dart';
import 'package:almona/presentation/screens/adhkar_screen.dart';
import 'package:almona/presentation/screens/search_screen.dart';
import 'package:almona/presentation/screens/profile_screen.dart';
import 'package:almona/presentation/widgets/home_header.dart';
import 'package:almona/presentation/widgets/current_dhikr_card.dart';
import 'package:almona/presentation/widgets/app_bar_widget.dart';
import 'package:almona/core/localization/app_localizations.dart';

class HomeScreen extends StatefulWidget {
  final Function(Locale) onLocaleChange;
  const HomeScreen({
    super.key,
    required this.onLocaleChange,
  });

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    final localizations = AppLocalizations.of(context);

    final screens = [
      HomeContent(
        onLocaleChange: widget.onLocaleChange,
      ),
      const AdhkarScreen(),
      const SearchScreen(),
      const ProfileScreen(),
    ];

    return Scaffold(
      backgroundColor: AppTheme.deepBlack,
      body: IndexedStack(
        index: _selectedIndex,
        children: screens,
      ),
      bottomNavigationBar: Container(
        height: 65,
        decoration: BoxDecoration(
          color: AppTheme.obsidian.withOpacity(0.95),
          border: Border(
            top: BorderSide(
              color: AppTheme.emerald.withOpacity(0.08),
              width: 0.5,
            ),
          ),
        ),
        child: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          currentIndex: _selectedIndex,
          onTap: (index) {
            setState(() {
              _selectedIndex = index;
            });
          },
          backgroundColor: Colors.transparent,
          selectedItemColor: AppTheme.emerald,
          unselectedItemColor: AppTheme.mutedText.withOpacity(0.5),
          selectedLabelStyle: GoogleFonts.cairo(
            fontSize: 11,
            fontWeight: FontWeight.w500,
          ),
          unselectedLabelStyle: GoogleFonts.cairo(
            fontSize: 10,
          ),
          elevation: 0,
          items: [
            BottomNavigationBarItem(
              icon: const Icon(Icons.home_outlined),
              activeIcon: const Icon(Icons.home),
              label: localizations?.home ?? 'الرئيسية',
            ),
            BottomNavigationBarItem(
              icon: const Icon(Icons.mosque_outlined),
              activeIcon: const Icon(Icons.mosque),
              label: localizations?.dhikr ?? 'الأذكار',
            ),
            BottomNavigationBarItem(
              icon: const Icon(Icons.search_outlined),
              activeIcon: const Icon(Icons.search),
              label: localizations?.search ?? 'بحث',
            ),
            BottomNavigationBarItem(
              icon: const Icon(Icons.person_outline),
              activeIcon: const Icon(Icons.person),
              label: localizations?.myWird ?? 'وردي',
            ),
          ],
        ),
      ),
    );
  }
}

class HomeContent extends StatefulWidget {
  final Function(Locale)? onLocaleChange;

  const HomeContent({
    super.key,
    this.onLocaleChange,
  });

  @override
  State<HomeContent> createState() => _HomeContentState();
}

class _HomeContentState extends State<HomeContent> {
  bool _isMorning = true;

  @override
  void initState() {
    super.initState();
    _checkTime();
  }

  void _checkTime() {
    final hour = DateTime.now().hour;
    setState(() {
      _isMorning = hour >= 5 && hour < 12;
    });
  }

  void _navigateToAdhkar(String category) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AdhkarScreen(
          initialCategory: category,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final localizations = AppLocalizations.of(context);

    return Scaffold(
      backgroundColor: AppTheme.deepBlack,
      appBar: const AppBarWidget(
        title: 'المنى',
        showNotification: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 12),
            HomeHeader(isMorning: _isMorning),
            const SizedBox(height: 16),
            GestureDetector(
              onTap: () => _navigateToAdhkar(
                _isMorning ? 'morning' : 'evening',
              ),
              child: CurrentDhikrCard(isMorning: _isMorning),
            ),
            const SizedBox(height: 24),
            _buildDailyWird(localizations),
            const SizedBox(height: 24),
            _buildQuickAccess(localizations),
            const SizedBox(height: 24),
            _buildAyahOfTheDay(localizations),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildDailyWird(AppLocalizations? localizations) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.obsidian,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: AppTheme.emerald.withOpacity(0.08),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                localizations?.dailyWird ?? 'وردك اليوم',
                style: GoogleFonts.cairo(
                  color: AppTheme.softWhite,
                  fontSize: 17,
                  fontWeight: FontWeight.w600,
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: AppTheme.emerald.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  '2 / 4',
                  style: TextStyle(
                    color: AppTheme.emerald,
                    fontSize: 12,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildWirdItem(Icons.wb_sunny, localizations?.morning ?? 'الصباح', true),
              _buildWirdItem(Icons.mosque, localizations?.afterPrayer ?? 'بعد الصلاة', true),
              _buildWirdItem(Icons.nightlight_round, localizations?.evening ?? 'المساء', false),
              _buildWirdItemText('💤', localizations?.sleep ?? 'النوم', false),
            ],
          ),
          const SizedBox(height: 12),
          GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const AdhkarScreen()),
              );
            },
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 8),
              decoration: BoxDecoration(
                color: AppTheme.emerald.withOpacity(0.05),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: AppTheme.emerald.withOpacity(0.1),
                ),
              ),
              child: Center(
                child: Text(
                  localizations?.completeWird ?? 'أكمل وردك اليوم →',
                  style: TextStyle(
                    color: AppTheme.emerald,
                    fontSize: 13,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWirdItem(IconData icon, String label, bool done) {
    return Flexible(
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: done ? AppTheme.emerald.withOpacity(0.15) : AppTheme.mutedText.withOpacity(0.05),
              shape: BoxShape.circle,
            ),
            child: Icon(
              icon,
              color: done ? AppTheme.emerald : AppTheme.mutedText.withOpacity(0.3),
              size: 20,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: done ? AppTheme.softWhite : AppTheme.mutedText.withOpacity(0.3),
              fontSize: 11,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWirdItemText(String text, String label, bool done) {
    return Flexible(
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: done ? AppTheme.emerald.withOpacity(0.15) : AppTheme.mutedText.withOpacity(0.05),
              shape: BoxShape.circle,
            ),
            child: Text(
              text,
              style: TextStyle(
                fontSize: 18,
                color: done ? AppTheme.emerald : AppTheme.mutedText.withOpacity(0.3),
              ),
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: done ? AppTheme.softWhite : AppTheme.mutedText.withOpacity(0.3),
              fontSize: 11,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQuickAccess(AppLocalizations? localizations) {
    final bool isArabic = Localizations.localeOf(context).languageCode == 'ar';

    final List<Map<String, dynamic>> items = [
      {
        'icon': Icons.wb_sunny,
        'label': localizations?.morning ?? 'الصباح',
        'category': 'morning',
      },
      {
        'icon': Icons.nightlight_round,
        'label': localizations?.evening ?? 'المساء',
        'category': 'evening',
      },
      {
        'icon': '💤',
        'label': localizations?.sleep ?? 'النوم',
        'category': 'sleep',
      },
      {
        'icon': Icons.mosque,
        'label': localizations?.afterPrayer ?? 'بعد الصلاة',
        'category': 'prayer',
      },
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          localizations?.quickDhikr ?? 'أذكار سريعة',
          style: GoogleFonts.cairo(
            color: AppTheme.softWhite,
            fontSize: 15,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 10),
        LayoutBuilder(
          builder: (context, constraints) {
            const double spacing = 6;
            final double itemWidth = (constraints.maxWidth - (spacing * 3)) / 4;

            return Row(
              textDirection: TextDirection.ltr,
              children: List.generate(items.length, (index) {
                final item = items[index];

                return Padding(
                  padding: EdgeInsets.only(
                    right: index < items.length - 1 ? spacing : 0,
                  ),
                  child: SizedBox(
                    width: itemWidth,
                    height: 88,
                    child: GestureDetector(
                      onTap: () => _navigateToAdhkar(
                        item['category'] as String,
                      ),
                      child: Container(
                        decoration: BoxDecoration(
                          color: AppTheme.obsidian,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                            color: AppTheme.mutedText.withOpacity(0.07),
                          ),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              width: 38,
                              height: 38,
                              decoration: BoxDecoration(
                                color: AppTheme.emerald.withOpacity(0.08),
                                shape: BoxShape.circle,
                              ),
                              alignment: Alignment.center,
                              child: item['icon'] is String
                                  ? Text(
                                      item['icon'] as String,
                                      style: const TextStyle(fontSize: 18),
                                    )
                                  : Icon(
                                      item['icon'] as IconData,
                                      color: AppTheme.emerald,
                                      size: 18,
                                    ),
                            ),
                            const SizedBox(height: 4),
                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 2),
                              child: Text(
                                item['label'] as String,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.center,
                                style: GoogleFonts.cairo(
                                  color: AppTheme.mutedText,
                                  fontSize: isArabic ? 8.5 : 10,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              }),
            );
          },
        ),
      ],
    );
  }

  Widget _buildAyahOfTheDay(AppLocalizations? localizations) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            AppTheme.emerald.withOpacity(0.05),
            AppTheme.deepBlack,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: AppTheme.emerald.withOpacity(0.05),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Text(
            localizations?.ayahOfDay ?? 'آية اليوم',
            style: TextStyle(
              color: AppTheme.mutedText,
              fontSize: 11,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            '﴿وَالذَّاكِرِينَ اللَّهَ كَثِيرًا وَالذَّاكِرَاتِ أَعَدَّ اللَّهُ لَهُم مَّغْفِرَةً وَأَجْرًا عَظِيمًا﴾',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: AppTheme.softWhite,
              fontSize: 16,
              height: 1.8,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'الأحزاب: 35',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: AppTheme.mutedText.withOpacity(0.4),
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }
}
