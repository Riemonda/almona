import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:almona/core/theme/app_theme.dart';
import 'package:almona/data/models/adhkar_model.dart';
import 'package:almona/presentation/widgets/adhkar_card.dart';
import 'package:almona/core/services/azkar_service.dart';
import 'package:almona/core/services/favorites_service.dart';
import 'package:almona/core/localization/app_localizations.dart';

class AdhkarScreen extends StatefulWidget {
  final String? initialCategory;
  
  const AdhkarScreen({super.key, this.initialCategory});

  @override
  State<AdhkarScreen> createState() => _AdhkarScreenState();
}

class _AdhkarScreenState extends State<AdhkarScreen> {
  String _selectedCategory = 'morning';
  List<AdhkarModel> _allAdhkar = [];
  List<AdhkarModel> _filteredAdhkar = [];
  bool _isLoading = true;
  bool _showFavoritesOnly = false;
  bool _isOffline = false;

  final List<Map<String, String>> categories = const [
    {'key': 'morning', 'label': 'morning'},
    {'key': 'evening', 'label': 'evening'},
    {'key': 'sleep', 'label': 'sleep'},
    {'key': 'prayer', 'label': 'after_prayer'},
    {'key': 'travel', 'label': 'travel'},
    {'key': 'general', 'label': 'all'},
  ];

  @override
  void initState() {
    super.initState();
    if (widget.initialCategory != null) {
      _selectedCategory = widget.initialCategory!;
    }
    _loadAzkar();
  }

  Future<void> _loadAzkar() async {
    setState(() => _isLoading = true);
    try {
      final azkar = await AzkarService.loadAzkar();
      setState(() {
        _allAdhkar = azkar;
        _filterAdhkar();
        _isLoading = false;
        _isOffline = false;
      });
    } catch (e) {
      final azkar = await AzkarService.loadAzkar();
      setState(() {
        _allAdhkar = azkar;
        _filterAdhkar();
        _isLoading = false;
        _isOffline = true;
      });
    }
  }

  Future<void> _refreshFromApi() async {
    setState(() => _isLoading = true);
    try {
      await AzkarService.refreshFromApi();
      final azkar = await AzkarService.loadAzkar();
      setState(() {
        _allAdhkar = azkar;
        _filterAdhkar();
        _isLoading = false;
        _isOffline = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('✅ تم تحديث الأذكار'),
          backgroundColor: AppTheme.emerald,
          duration: Duration(seconds: 2),
        ),
      );
    } catch (e) {
      setState(() => _isLoading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('❌ فشل التحديث'),
          backgroundColor: Colors.red,
          duration: Duration(seconds: 2),
        ),
      );
    }
  }

  void _filterAdhkar() {
    List<AdhkarModel> filtered;
    
    if (_selectedCategory == 'general') {
      filtered = _allAdhkar.where((a) => a.isActive).toList();
    } else {
      filtered = _allAdhkar
          .where((a) => a.category == _selectedCategory && a.isActive)
          .toList()
        ..sort((a, b) => a.id.compareTo(b.id));
    }
    
    if (_showFavoritesOnly) {
      filtered = filtered.where((a) => FavoritesService.isFavorite(a)).toList();
    }
    
    setState(() {
      _filteredAdhkar = filtered;
    });
  }

  void _toggleFavorite(AdhkarModel adhkar) {
    FavoritesService.toggleFavorite(adhkar);
    _filterAdhkar();
  }

  bool _isFavorite(AdhkarModel adhkar) {
    return FavoritesService.isFavorite(adhkar);
  }

  @override
  Widget build(BuildContext context) {
    final localizations = AppLocalizations.of(context);
    
    return Scaffold(
      backgroundColor: AppTheme.deepBlack,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(110),
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [AppTheme.deepBlack, AppTheme.obsidian],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        localizations?.dhikr ?? 'الأذكار',
                        style: GoogleFonts.cairo(
                          color: AppTheme.softWhite,
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Row(
                        children: [
                          Text(
                            '${_allAdhkar.length} ${localizations?.dhikr ?? 'ذكر'}',
                            style: TextStyle(
                              color: AppTheme.mutedText,
                              fontSize: 12,
                            ),
                          ),
                          if (_isOffline) ...[
                            const SizedBox(width: 8),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                color: Colors.orange.withOpacity(0.2),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Text(
                                '📶 Offline',
                                style: TextStyle(
                                  color: Colors.orange,
                                  fontSize: 10,
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      GestureDetector(
                        onTap: () {
                          setState(() {
                            _showFavoritesOnly = !_showFavoritesOnly;
                            _filterAdhkar();
                          });
                        },
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: _showFavoritesOnly 
                                ? AppTheme.emerald.withOpacity(0.15)
                                : AppTheme.mutedText.withOpacity(0.05),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: _showFavoritesOnly
                                  ? AppTheme.emerald.withOpacity(0.2)
                                  : AppTheme.mutedText.withOpacity(0.05),
                            ),
                          ),
                          child: Icon(
                            _showFavoritesOnly ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                            color: _showFavoritesOnly ? AppTheme.emerald : AppTheme.mutedText.withOpacity(0.3),
                            size: 22,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      GestureDetector(
                        onTap: _refreshFromApi,
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: AppTheme.emerald.withOpacity(0.05),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: AppTheme.emerald.withOpacity(0.1),
                            ),
                          ),
                          child: Icon(
                            Icons.sync_rounded,
                            color: AppTheme.emerald,
                            size: 22,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation(Color(0xFF00C896)),
              ),
            )
          : Column(
              children: [
                Container(
                  height: 46,
                  margin: const EdgeInsets.symmetric(horizontal: 16),
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: categories.length,
                    itemBuilder: (context, index) {
                      final cat = categories[index];
                      final isSelected = _selectedCategory == cat['key'];
                      final itemCount = _allAdhkar
                          .where((a) => a.category == cat['key'] && a.isActive)
                          .length;
                      final labelKey = cat['label']!;
                      final String label = localizations?.translate(labelKey) ?? labelKey;
                      
                      return GestureDetector(
                        onTap: () {
                          setState(() {
                            _selectedCategory = cat['key']!;
                            _filterAdhkar();
                          });
                        },
                        child: Container(
                          margin: const EdgeInsets.only(right: 8),
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                          decoration: BoxDecoration(
                            gradient: isSelected 
                                ? AppTheme.primaryGradient
                                : null,
                            color: isSelected ? null : AppTheme.obsidian,
                            borderRadius: BorderRadius.circular(24),
                            border: Border.all(
                              color: isSelected 
                                  ? AppTheme.emerald 
                                  : AppTheme.mutedText.withOpacity(0.05),
                            ),
                          ),
                          child: Row(
                            children: [
                              Text(
                                isSelected ? '●' : '○',
                                style: TextStyle(
                                  color: isSelected ? AppTheme.deepBlack : AppTheme.mutedText,
                                  fontSize: 10,
                                ),
                              ),
                              const SizedBox(width: 6),
                              Text(
                                label,
                                style: TextStyle(
                                  color: isSelected 
                                      ? AppTheme.deepBlack 
                                      : AppTheme.mutedText,
                                  fontSize: 13,
                                  fontWeight: isSelected 
                                      ? FontWeight.w600 
                                      : FontWeight.normal,
                                ),
                              ),
                              if (itemCount > 0 && !isSelected) ...[
                                const SizedBox(width: 4),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                                  decoration: BoxDecoration(
                                    color: AppTheme.mutedText.withOpacity(0.1),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: Text(
                                    '$itemCount',
                                    style: TextStyle(
                                      color: AppTheme.mutedText.withOpacity(0.5),
                                      fontSize: 9,
                                    ),
                                  ),
                                ),
                              ],
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 12),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        '${_filteredAdhkar.length} ${localizations?.dhikr ?? 'ذكر'}',
                        style: TextStyle(
                          color: AppTheme.mutedText.withOpacity(0.4),
                          fontSize: 12,
                        ),
                      ),
                      if (_selectedCategory != 'general')
                        GestureDetector(
                          onTap: () {
                            setState(() {
                              _selectedCategory = 'general';
                              _filterAdhkar();
                            });
                          },
                          child: Text(
                            localizations?.all ?? 'عرض الكل',
                            style: TextStyle(
                              color: AppTheme.emerald.withOpacity(0.5),
                              fontSize: 12,
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
                Expanded(
                  child: _filteredAdhkar.isEmpty
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.mosque_outlined,
                                size: 48,
                                color: AppTheme.mutedText.withOpacity(0.1),
                              ),
                              const SizedBox(height: 16),
                              Text(
                                _showFavoritesOnly 
                                    ? (localizations?.noDhikr ?? 'لا توجد أذكار في المفضلة')
                                    : (localizations?.noDhikr ?? 'لا توجد أذكار في هذا القسم'),
                                style: TextStyle(
                                  color: AppTheme.mutedText.withOpacity(0.5),
                                  fontSize: 16,
                                ),
                              ),
                            ],
                          ),
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.all(16),
                          itemCount: _filteredAdhkar.length,
                          itemBuilder: (context, index) {
                            final adhkar = _filteredAdhkar[index];
                            final isEven = index % 2 == 0;
                            final isFav = _isFavorite(adhkar);
                            return AdhkarCard(
                              adhkar: adhkar,
                              onTap: () {},
                              isEven: isEven,
                              isFavorite: isFav,
                              onFavoriteToggle: () => _toggleFavorite(adhkar),
                            );
                          },
                        ),
                ),
              ],
            ),
    );
  }
}
