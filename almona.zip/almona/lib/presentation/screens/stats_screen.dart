import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:almona/core/theme/app_theme.dart';
import 'package:almona/core/services/favorites_service.dart';
import 'package:almona/core/localization/app_localizations.dart';
import 'package:hive_flutter/hive_flutter.dart';

class StatsScreen extends StatefulWidget {
  const StatsScreen({super.key});

  @override
  State<StatsScreen> createState() => _StatsScreenState();
}

class _StatsScreenState extends State<StatsScreen> {
  int _favoritesCount = 0;
  int _totalDhikrCount = 0;
  int _streakDays = 0;
  int _todayDhikrCount = 0;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadStats();
  }

  void _loadStats() async {
    setState(() => _isLoading = true);
    
    final statsBox = await Hive.openBox('stats');
    
    setState(() {
      _favoritesCount = FavoritesService.count;
      _totalDhikrCount = statsBox.get('total_dhikr_count', defaultValue: 0);
      _streakDays = statsBox.get('streak_days', defaultValue: 0);
      _todayDhikrCount = statsBox.get('today_dhikr_count', defaultValue: 0);
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final localizations = AppLocalizations.of(context);
    final int routineCompleted = _todayDhikrCount >= 3 ? 3 : _todayDhikrCount;
    final bool isRoutineComplete = _todayDhikrCount >= 3;
    final int progressPercent = (_todayDhikrCount > 100) ? 100 : _todayDhikrCount;

    return Scaffold(
      backgroundColor: AppTheme.deepBlack,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text(
          localizations?.stats ?? 'إحصائياتي',
          style: GoogleFonts.cairo(
            color: AppTheme.softWhite,
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
      ),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation(Color(0xFF00C896)),
              ),
            )
          : SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Row(
                    children: [
                      _buildStatCard(
                        icon: Icons.favorite_rounded,
                        value: '$_favoritesCount',
                        label: localizations?.favoritesCount ?? 'مفضلة',
                        color: AppTheme.emerald,
                      ),
                      const SizedBox(width: 12),
                      _buildStatCard(
                        icon: Icons.mosque_rounded,
                        value: '$_totalDhikrCount',
                        label: localizations?.totalDhikr ?? 'إجمالي الأذكار',
                        color: AppTheme.jade,
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      _buildStatCard(
                        icon: Icons.local_fire_department_rounded,
                        value: '$_streakDays',
                        label: localizations?.streakDays ?? 'يوم متتالي',
                        color: AppTheme.mintGlow,
                      ),
                      const SizedBox(width: 12),
                      _buildStatCard(
                        icon: Icons.today_rounded,
                        value: '$_todayDhikrCount',
                        label: localizations?.todayDhikr ?? 'ذكر اليوم',
                        color: AppTheme.softWhite,
                      ),
                    ],
                  ),
                  
                  const SizedBox(height: 24),
                  
                  // بطاقة التقدم اليومي
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          AppTheme.emerald.withOpacity(0.05),
                          AppTheme.deepBlack,
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: AppTheme.emerald.withOpacity(0.05),
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              localizations?.progress ?? 'تقدمك اليوم',
                              style: GoogleFonts.cairo(
                                color: AppTheme.softWhite,
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(
                                color: isRoutineComplete
                                    ? AppTheme.emerald.withOpacity(0.15)
                                    : AppTheme.mutedText.withOpacity(0.05),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Text(
                                isRoutineComplete
                                    ? '🎉 ${localizations?.completed ?? 'أكملت وردك اليومي!'}'
                                    : '$routineCompleted / ٣',
                                style: TextStyle(
                                  color: isRoutineComplete
                                      ? AppTheme.emerald
                                      : AppTheme.mutedText,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 16),
                        
                        // شريط التقدم مع نقطة الروتين
                        Stack(
                          children: [
                            Container(
                              width: double.infinity,
                              height: 8,
                              decoration: BoxDecoration(
                                color: AppTheme.mutedText.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(4),
                              ),
                              child: FractionallySizedBox(
                                widthFactor: progressPercent / 100,
                                child: Container(
                                  decoration: BoxDecoration(
                                    gradient: AppTheme.primaryGradient,
                                    borderRadius: BorderRadius.circular(4),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              left: (3 / 100) * 100,
                              top: -4,
                              child: Container(
                                width: 16,
                                height: 16,
                                decoration: BoxDecoration(
                                  color: routineCompleted >= 3
                                      ? AppTheme.emerald
                                      : AppTheme.mintGlow.withOpacity(0.5),
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: AppTheme.deepBlack,
                                    width: 2,
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: routineCompleted >= 3
                                          ? AppTheme.emerald.withOpacity(0.3)
                                          : AppTheme.mintGlow.withOpacity(0.1),
                                      blurRadius: 8,
                                    ),
                                  ],
                                ),
                                child: Center(
                                  child: Text(
                                    '٣',
                                    style: TextStyle(
                                      color: routineCompleted >= 3
                                          ? AppTheme.deepBlack
                                          : AppTheme.mutedText.withOpacity(0.5),
                                      fontSize: 8,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  '$_todayDhikrCount',
                                  style: TextStyle(
                                    color: AppTheme.emerald,
                                    fontSize: 20,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Text(
                                  '${localizations?.from ?? 'من أصل'} ١٠٠',
                                  style: TextStyle(
                                    color: AppTheme.mutedText.withOpacity(0.3),
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Text(
                                  '🟢 ${localizations?.routine ?? 'الروتين اليومي'}',
                                  style: TextStyle(
                                    color: AppTheme.mintGlow.withOpacity(0.5),
                                    fontSize: 11,
                                  ),
                                ),
                                Text(
                                  isRoutineComplete
                                      ? '✅ ${localizations?.morning ?? 'الصباح'}، ${localizations?.evening ?? 'المساء'}، ${localizations?.sleep ?? 'النوم'}'
                                      : '${localizations?.morning ?? 'الصباح'}، ${localizations?.evening ?? 'المساء'}، ${localizations?.sleep ?? 'النوم'}',
                                  style: TextStyle(
                                    color: isRoutineComplete
                                        ? AppTheme.emerald
                                        : AppTheme.mutedText.withOpacity(0.3),
                                    fontSize: 12,
                                    fontWeight: isRoutineComplete
                                        ? FontWeight.w500
                                        : FontWeight.normal,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  
                  const SizedBox(height: 24),
                  
                  // رسالة تحفيزية
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: AppTheme.obsidian,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: AppTheme.mutedText.withOpacity(0.05),
                      ),
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: isRoutineComplete
                                ? AppTheme.emerald.withOpacity(0.1)
                                : AppTheme.mutedText.withOpacity(0.05),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Icon(
                            isRoutineComplete
                                ? Icons.emoji_events_rounded
                                : Icons.emoji_emotions_outlined,
                            color: isRoutineComplete
                                ? AppTheme.emerald
                                : AppTheme.mutedText.withOpacity(0.3),
                            size: 28,
                          ),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                isRoutineComplete
                                    ? '🌟 ${localizations?.keepGoing ?? 'ماشاء الله! أكملت وردك اليومي'}'
                                    : '🌱 ${localizations?.startJourney ?? 'ابدأ روتينك اليومي'}',
                                style: TextStyle(
                                  color: AppTheme.softWhite.withOpacity(0.8),
                                  fontSize: 15,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                isRoutineComplete
                                    ? '${localizations?.morning ?? 'أذكار الصباح'}، ${localizations?.evening ?? 'المساء'}، ${localizations?.sleep ?? 'النوم'}'
                                    : '${localizations?.morning ?? 'أذكار الصباح'}، ${localizations?.evening ?? 'المساء'}، ${localizations?.sleep ?? 'النوم'} ${localizations?.remaining ?? 'تنتظرك'}',
                                style: TextStyle(
                                  color: AppTheme.mutedText.withOpacity(0.3),
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
    );
  }

  Widget _buildStatCard({
    required IconData icon,
    required String value,
    required String label,
    required Color color,
  }) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppTheme.obsidian,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: color.withOpacity(0.05),
          ),
        ),
        child: Column(
          children: [
            Icon(
              icon,
              color: color.withOpacity(0.5),
              size: 28,
            ),
            const SizedBox(height: 8),
            Text(
              value,
              style: GoogleFonts.cairo(
                color: color,
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              label,
              style: TextStyle(
                color: AppTheme.mutedText.withOpacity(0.4),
                fontSize: 12,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
