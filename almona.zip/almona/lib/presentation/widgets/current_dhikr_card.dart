import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:almona/core/theme/app_theme.dart';
import 'package:almona/core/localization/app_localizations.dart';

class CurrentDhikrCard extends StatelessWidget {
  final bool isMorning;

  const CurrentDhikrCard({super.key, required this.isMorning});

  @override
  Widget build(BuildContext context) {
    final localizations = AppLocalizations.of(context);
    final bool isEnglish = localizations?.locale.languageCode == 'en';
    
    final String timeText = isMorning 
        ? (localizations?.morningDhikr ?? 'صباحك ذكر') 
        : (localizations?.eveningDhikr ?? 'مساؤك سكينة');
    final String emoji = isMorning ? '🌅' : '🌙';
    final String subText = isMorning 
        ? (localizations?.morningTime ?? 'حان وقت أذكار الصباح')
        : (localizations?.eveningTime ?? 'حان وقت أذكار المساء');
    final String startText = localizations?.startDhikr ?? 'ابدأ الأذكار';

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [AppTheme.emerald.withOpacity(0.08), AppTheme.deepBlack],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.emerald.withOpacity(0.06)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            localizations?.now ?? 'الآن',
            style: TextStyle(color: AppTheme.mutedText, fontSize: 11, letterSpacing: 1),
          ),
          const SizedBox(height: 4),
          Row(
            children: [
              Text(
                timeText,
                style: GoogleFonts.cairo(
                  color: AppTheme.softWhite,
                  fontSize: isEnglish ? 18 : 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(width: 6),
              Text(emoji, style: TextStyle(fontSize: isEnglish ? 18 : 20)),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            subText,
            style: TextStyle(
              color: AppTheme.mutedText,
              fontSize: isEnglish ? 12 : 13,
            ),
          ),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
            decoration: BoxDecoration(
              gradient: AppTheme.primaryGradient,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  startText,
                  style: TextStyle(
                    color: AppTheme.deepBlack,
                    fontSize: isEnglish ? 13 : 14,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(width: 6),
                Icon(
                  Icons.arrow_forward_rounded,
                  color: AppTheme.deepBlack,
                  size: isEnglish ? 14 : 16,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
