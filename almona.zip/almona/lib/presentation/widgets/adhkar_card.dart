import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:almona/core/theme/app_theme.dart';
import 'package:almona/data/models/adhkar_model.dart';
import 'package:almona/presentation/screens/dhikr_detail_screen.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:almona/core/services/wird_service.dart';

class AdhkarCard extends StatefulWidget {
  final AdhkarModel adhkar;
  final VoidCallback onTap;
  final bool isEven;
  final bool isFavorite;
  final VoidCallback onFavoriteToggle;

  const AdhkarCard({
    super.key,
    required this.adhkar,
    required this.onTap,
    this.isEven = true,
    this.isFavorite = false,
    required this.onFavoriteToggle,
  });

  @override
  State<AdhkarCard> createState() => _AdhkarCardState();
}

class _AdhkarCardState extends State<AdhkarCard> {
  int _currentCount = 0;
  bool _isCompleted = false;
  late Box statsBox;

  @override
  void initState() {
    super.initState();
    _loadStats();
  }

  void _loadStats() async {
    statsBox = await Hive.openBox('stats');
  }

  void _incrementCounter() {
    if (_isCompleted) return;
    setState(() {
      _currentCount++;
      if (_currentCount >= widget.adhkar.repetitions) {
        _currentCount = widget.adhkar.repetitions;
        _isCompleted = true;
        _updateStats();
      }
    });
  }

  void _updateStats() {
    int total = statsBox.get('total_dhikr_count', defaultValue: 0);
    statsBox.put('total_dhikr_count', total + 1);
    
    int today = statsBox.get('today_dhikr_count', defaultValue: 0);
    statsBox.put('today_dhikr_count', today + 1);
    
    int streak = statsBox.get('streak_days', defaultValue: 0);
    if (streak == 0) {
      statsBox.put('streak_days', 1);
    }
    
    Map<String, int> categories = Map<String, int>.from(
      statsBox.get('category_counts', defaultValue: {})
    );
    categories[widget.adhkar.category] = (categories[widget.adhkar.category] ?? 0) + 1;
    statsBox.put('category_counts', categories);
    
    WirdService.setCategoryComplete(widget.adhkar.category, true);
  }

  void _resetCounter() {
    setState(() {
      _currentCount = 0;
      _isCompleted = false;
    });
  }

  void _openDetail() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => DhikrDetailScreen(adhkar: widget.adhkar),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final reference = widget.adhkar.reference ?? '';
    final hasReference = reference.isNotEmpty;
    final displayText = widget.adhkar.shortText.isNotEmpty 
        ? widget.adhkar.shortText 
        : widget.adhkar.arabicText;
    
    return GestureDetector(
      onTap: _openDetail,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: widget.isEven
                ? [AppTheme.obsidian, AppTheme.deepBlack]
                : [AppTheme.deepBlack, AppTheme.obsidian],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: _isCompleted 
                ? AppTheme.emerald.withOpacity(0.15) 
                : AppTheme.mutedText.withOpacity(0.05),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              displayText,
              style: TextStyle(
                color: AppTheme.softWhite,
                fontSize: 16,
                height: 1.8,
                fontFamily: 'Uthmanic',
              ),
              textAlign: TextAlign.right,
              textDirection: TextDirection.rtl,
            ),
            if (widget.adhkar.englishText.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text(
                widget.adhkar.englishText,
                style: TextStyle(
                  color: AppTheme.mutedText.withOpacity(0.7),
                  fontSize: 14,
                  height: 1.5,
                ),
                textAlign: TextAlign.right,
              ),
            ],
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Icon(Icons.book_outlined, size: 12, color: AppTheme.mutedText.withOpacity(0.2)),
                    const SizedBox(width: 4),
                    Text(
                      widget.adhkar.source,
                      style: TextStyle(color: AppTheme.mutedText.withOpacity(0.3), fontSize: 11),
                    ),
                    if (hasReference) ...[
                      const SizedBox(width: 4),
                      Text('($reference)', style: TextStyle(color: AppTheme.mutedText.withOpacity(0.2), fontSize: 10)),
                    ],
                  ],
                ),
                GestureDetector(
                  onTap: widget.onFavoriteToggle,
                  child: Icon(
                    widget.isFavorite ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                    color: widget.isFavorite ? AppTheme.emerald : AppTheme.mutedText.withOpacity(0.2),
                    size: 22,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '${widget.adhkar.repetitions} مرات',
                  style: TextStyle(color: _isCompleted ? AppTheme.emerald : AppTheme.mutedText, fontSize: 13, fontWeight: FontWeight.w500),
                ),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                      decoration: BoxDecoration(
                        gradient: _isCompleted ? AppTheme.primaryGradient : null,
                        color: _isCompleted ? null : AppTheme.obsidian,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: _isCompleted ? AppTheme.emerald : AppTheme.mutedText.withOpacity(0.05)),
                      ),
                      child: Row(
                        children: [
                          Text(
                            '$_currentCount / ${widget.adhkar.repetitions}',
                            style: TextStyle(color: _isCompleted ? AppTheme.deepBlack : AppTheme.softWhite, fontSize: 14, fontWeight: FontWeight.bold),
                          ),
                          if (_isCompleted) ...[
                            const SizedBox(width: 6),
                            Icon(Icons.check_circle_rounded, color: AppTheme.deepBlack, size: 16),
                          ],
                        ],
                      ),
                    ),
                    const SizedBox(width: 8),
                    if (!_isCompleted)
                      GestureDetector(
                        onTap: _incrementCounter,
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: AppTheme.emerald.withOpacity(0.05),
                            shape: BoxShape.circle,
                          ),
                          child: Icon(Icons.add_rounded, color: AppTheme.emerald, size: 20),
                        ),
                      ),
                    if (_isCompleted)
                      GestureDetector(
                        onTap: _resetCounter,
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: AppTheme.mutedText.withOpacity(0.05),
                            shape: BoxShape.circle,
                          ),
                          child: Icon(Icons.refresh_rounded, color: AppTheme.mutedText.withOpacity(0.3), size: 20),
                        ),
                      ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
