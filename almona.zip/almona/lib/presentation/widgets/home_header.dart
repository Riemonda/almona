import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:almona/core/theme/app_theme.dart';
import 'package:almona/core/localization/app_localizations.dart';

class HomeHeader extends StatelessWidget {
  final bool isMorning;
  
  const HomeHeader({super.key, required this.isMorning});

  @override
  Widget build(BuildContext context) {
    final localizations = AppLocalizations.of(context);
    final now = DateTime.now();
    final dayOfMonth = now.day;
    
    // 30 تحية مختلفة للصباح
    final List<String> morningGreetings = [
      'السلام عليكم، صباح النور ☀️',
      'السلام عليكم، صباح الإيمان ☀️',
      'السلام عليكم، صباح القرآن ☀️',
      'السلام عليكم، صباح الذكر ☀️',
      'السلام عليكم، صباح السكينة ☀️',
      'السلام عليكم، صباح الطمأنينة ☀️',
      'السلام عليكم، صباح الرضا ☀️',
      'السلام عليكم، صباح اليقين ☀️',
      'السلام عليكم، صباح التقوى ☀️',
      'السلام عليكم، صباح الصبر ☀️',
      'السلام عليكم، صباح الشكر ☀️',
      'السلام عليكم، صباح التوبة ☀️',
      'السلام عليكم، صباح العبادة ☀️',
      'السلام عليكم، صباح البركة ☀️',
      'السلام عليكم، صباح الخير واليمن ☀️',
      'السلام عليكم، صباح النجاح ☀️',
      'السلام عليكم، صباح القبول ☀️',
      'السلام عليكم، صباح الهداية ☀️',
      'السلام عليكم، صباح الراحة ☀️',
      'السلام عليكم، صباح السعادة ☀️',
      'السلام عليكم، صباح الأمل ☀️',
      'السلام عليكم، صباح العطاء ☀️',
      'السلام عليكم، صباح الرحمة ☀️',
      'السلام عليكم، صباح المغفرة ☀️',
      'السلام عليكم، صباح النصر ☀️',
      'السلام عليكم، صباح العزيمة ☀️',
      'السلام عليكم، صباح الإخلاص ☀️',
      'السلام عليكم، صباح الحمد ☀️',
      'السلام عليكم، صباح التسبيح ☀️',
      'السلام عليكم، صباح الدعاء ☀️',
    ];
    
    // 30 تحية مختلفة للمساء
    final List<String> eveningGreetings = [
      'السلام عليكم، مساء النور 🌙',
      'السلام عليكم، مساء الإيمان 🌙',
      'السلام عليكم، مساء الذكر 🌙',
      'السلام عليكم، مساء السكينة 🌙',
      'السلام عليكم، مساء الطمأنينة 🌙',
      'السلام عليكم، مساء الرضا 🌙',
      'السلام عليكم، مساء اليقين 🌙',
      'السلام عليكم، مساء التقوى 🌙',
      'السلام عليكم، مساء الصبر 🌙',
      'السلام عليكم، مساء الشكر 🌙',
      'السلام عليكم، مساء التوبة 🌙',
      'السلام عليكم، مساء العبادة 🌙',
      'السلام عليكم، مساء البركة 🌙',
      'السلام عليكم، مساء الخير 🌙',
      'السلام عليكم، مساء السلام 🌙',
      'السلام عليكم، مساء الهدوء 🌙',
      'السلام عليكم، مساء الراحة 🌙',
      'السلام عليكم، مساء السعادة 🌙',
      'السلام عليكم، مساء الأمل 🌙',
      'السلام عليكم، مساء العطاء 🌙',
      'السلام عليكم، مساء الرحمة 🌙',
      'السلام عليكم، مساء المغفرة 🌙',
      'السلام عليكم، مساء النصر 🌙',
      'السلام عليكم، مساء العزيمة 🌙',
      'السلام عليكم، مساء الإخلاص 🌙',
      'السلام عليكم، مساء الحمد 🌙',
      'السلام عليكم، مساء التسبيح 🌙',
      'السلام عليكم، مساء الدعاء 🌙',
      'السلام عليكم، مساء الليل 🌙',
      'السلام عليكم، مساء السحر 🌙',
    ];
    
    final index = (dayOfMonth - 1) % 30;
    String greeting;
    String subText;
    
    if (isMorning) {
      greeting = morningGreetings[index];
      subText = localizations?.subtitleMorning ?? 'ابدأ يومك بذكر الله';
    } else {
      greeting = eveningGreetings[index];
      subText = localizations?.subtitleEvening ?? 'ذكرك نور في قلبك';
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(
              greeting,
              style: GoogleFonts.cairo(
                color: AppTheme.softWhite,
                fontSize: 18,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
        Text(
          subText,
          style: TextStyle(
            color: AppTheme.mutedText.withOpacity(0.6),
            fontSize: 13,
          ),
        ),
      ],
    );
  }
}
