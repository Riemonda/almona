import 'package:almona/data/models/adhkar_model.dart';

class FavoriteModel {
  final int id;
  final String arabicText;
  final String englishText;
  final int repetitions;
  final String source;
  final String category;
  final String? reference;
  
  FavoriteModel({
    required this.id,
    required this.arabicText,
    required this.englishText,
    required this.repetitions,
    required this.source,
    required this.category,
    this.reference,
  });
  
  factory FavoriteModel.fromAdhkar(AdhkarModel adhkar) {
    return FavoriteModel(
      id: adhkar.id,
      arabicText: adhkar.arabicText,
      englishText: adhkar.englishText,
      repetitions: adhkar.repetitions,
      source: adhkar.source,
      category: adhkar.category,
      reference: adhkar.reference,
    );
  }
  
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'arabic_text': arabicText,
      'english_text': englishText,
      'repetitions': repetitions,
      'source': source,
      'category': category,
      'reference': reference,
    };
  }
  
  factory FavoriteModel.fromJson(Map<String, dynamic> json) {
    return FavoriteModel(
      id: json['id'] ?? 0,
      arabicText: json['arabic_text'] ?? '',
      englishText: json['english_text'] ?? '',
      repetitions: json['repetitions'] ?? 1,
      source: json['source'] ?? '',
      category: json['category'] ?? '',
      reference: json['reference'],
    );
  }
}
