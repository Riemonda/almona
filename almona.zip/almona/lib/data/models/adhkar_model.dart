import 'package:equatable/equatable.dart';

class AdhkarModel extends Equatable {
  final int id;
  final String category;
  final String arabicText;
  final String shortText;
  final String englishText;
  final int repetitions;
  final String source;
  final String? reference;
  final int order;
  final bool isActive;
  
  const AdhkarModel({
    required this.id,
    required this.category,
    required this.arabicText,
    this.shortText = '',
    required this.englishText,
    required this.repetitions,
    required this.source,
    this.reference,
    required this.order,
    required this.isActive,
  });
  
  factory AdhkarModel.fromJson(Map<String, dynamic> json) {
    return AdhkarModel(
      id: json['id'] ?? 0,
      category: json['category'] ?? '',
      arabicText: json['arabic_text'] ?? '',
      shortText: json['short_text'] ?? '',
      englishText: json['english_text'] ?? '',
      repetitions: json['repetitions'] ?? 1,
      source: json['source'] ?? '',
      reference: json['reference'],
      order: json['order'] ?? 0,
      isActive: json['is_active'] ?? true,
    );
  }
  
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'category': category,
      'arabic_text': arabicText,
      'short_text': shortText,
      'english_text': englishText,
      'repetitions': repetitions,
      'source': source,
      'reference': reference,
      'order': order,
      'is_active': isActive,
    };
  }
  
  @override
  List<Object?> get props => [id, category, arabicText, englishText, repetitions];
}
