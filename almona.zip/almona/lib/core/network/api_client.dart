import 'package:dio/dio.dart';

class ApiClient {
  final Dio _dio;
  final String baseUrl;

  ApiClient(this._dio, {this.baseUrl = 'https://Almonaapp.pythonanywhere.com/api/'});

  Future<Map<String, dynamic>> getAdhkar() async {
    final response = await _dio.get(
      '$baseUrl/adhkar/',
      options: Options(
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
      ),
    );
    return response.data as Map<String, dynamic>;
  }
}
