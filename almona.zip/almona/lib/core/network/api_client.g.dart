// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'api_client.dart';

class _ApiClient implements ApiClient {
  _ApiClient(this._dio, {this.baseUrl}) {
    baseUrl ??= 'https://Almonaapp.pythonanywhere.com/api/';
  }

  final Dio _dio;
  String? baseUrl;

  @override
  Future<List<dynamic>> getAdhkar() async {
    final _response = await _dio.get(
      'adhkar/',
      options: Options(
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
      ),
    );
    return _response.data;
  }

  @override
  Future<List<dynamic>> getCategories() async {
    final _response = await _dio.get(
      'categories/',
      options: Options(
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
      ),
    );
    return _response.data;
  }
}
