import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  // الألوان الأساسية (بأسماء متوافقة مع جميع الملفات)
  static const Color primaryGreen = Color(0xFF00C896);
  static const Color primaryText = Color(0xFFF5F8F6);
  static const Color secondaryText = Color(0xFF98A49F);
  static const Color backgroundBlack = Color(0xFF050807);
  static const Color cardDark = Color(0xFF0B1713);
  
  // ألوان إضافية
  static const Color deepBlack = Color(0xFF050807);
  static const Color obsidian = Color(0xFF0A100D);
  static const Color emerald = Color(0xFF00C896);
  static const Color jade = Color(0xFF18E0A0);
  static const Color mintGlow = Color(0xFF7CFFD7);
  static const Color softWhite = Color(0xFFF5F8F6);
  static const Color mutedText = Color(0xFF98A49F);
  
  // تدرج
  static const LinearGradient primaryGradient = LinearGradient(
    colors: [Color(0xFF00C896), Color(0xFF18E0A0)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  static ThemeData darkTheme = ThemeData(
    brightness: Brightness.dark,
    scaffoldBackgroundColor: deepBlack,
    primaryColor: emerald,
    colorScheme: const ColorScheme.dark(
      primary: Color(0xFF00C896),
      secondary: Color(0xFF18E0A0),
      background: Color(0xFF050807),
      surface: Color(0xFF0A100D),
      onPrimary: Color(0xFF050807),
      onSecondary: Color(0xFF050807),
    ),
    textTheme: TextTheme(
      displayLarge: GoogleFonts.cairo(color: softWhite, fontSize: 32, fontWeight: FontWeight.bold),
      displayMedium: GoogleFonts.cairo(color: softWhite, fontSize: 28, fontWeight: FontWeight.w600),
      headlineLarge: GoogleFonts.cairo(color: softWhite, fontSize: 24, fontWeight: FontWeight.w600),
      headlineMedium: GoogleFonts.cairo(color: softWhite, fontSize: 20, fontWeight: FontWeight.w500),
      bodyLarge: GoogleFonts.cairo(color: softWhite, fontSize: 18, height: 1.8),
      bodyMedium: GoogleFonts.cairo(color: mutedText, fontSize: 16, height: 1.6),
      bodySmall: GoogleFonts.cairo(color: mutedText, fontSize: 14, height: 1.5),
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.transparent,
      elevation: 0,
      centerTitle: true,
      iconTheme: IconThemeData(color: Color(0xFF00C896)),
      titleTextStyle: TextStyle(
        color: Color(0xFFF5F8F6),
        fontSize: 20,
        fontWeight: FontWeight.w600,
      ),
    ),
    cardTheme: const CardThemeData(
      color: Color(0xFF0B1713),
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(20)),
      ),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: const Color(0xFF00C896),
        foregroundColor: const Color(0xFF050807),
        padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        elevation: 0,
      ),
    ),
  );
}
