import 'package:almona/data/models/adhkar_model.dart';

class SearchService {
  // دالة لإزالة التشكيل من النص العربي
  static String removeDiacritics(String text) {
    // قائمة بأحرف التشكيل في العربية
    final diacritics = [
      'َ', 'ً', 'ُ', 'ٌ', 'ِ', 'ٍ', 'ْ', 'ّ', 'َ', 'ً', 'ُ', 'ٌ', 'ِ', 'ٍ', 'ْ', 'ّ',
      'ٰ', 'ۖ', 'ۗ', 'ۘ', 'ۙ', 'ۚ', 'ۛ', 'ۜ', '۞', '۟', '۠', 'ۡ', 'ۢ', 'ۣ', 'ۤ', 'ۥ', 'ۦ'
    ];
    
    String result = text;
    for (var char in diacritics) {
      result = result.replaceAll(char, '');
    }
    return result;
  }

  static List<AdhkarModel> search(List<AdhkarModel> allAdhkar, String query) {
    if (query.isEmpty) return [];
    
    // إزالة التشكيل من كلمة البحث
    String normalizedQuery = removeDiacritics(query).toLowerCase();
    
    return allAdhkar.where((adhkar) {
      String normalizedArabic = removeDiacritics(adhkar.arabicText).toLowerCase();
      String normalizedEnglish = adhkar.englishText.toLowerCase();
      
      return normalizedArabic.contains(normalizedQuery) ||
          normalizedEnglish.contains(normalizedQuery) ||
          adhkar.category.contains(query) ||
          adhkar.source.contains(query);
    }).toList();
  }
}
