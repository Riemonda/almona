import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest.dart' as tz;

class NotificationService {
  static final FlutterLocalNotificationsPlugin _notifications =
      FlutterLocalNotificationsPlugin();

  static Future<void> initialize() async {
    const AndroidInitializationSettings androidSettings =
        AndroidInitializationSettings('@mipmap/ic_launcher');
    const DarwinInitializationSettings iosSettings =
        DarwinInitializationSettings();
    const InitializationSettings settings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );

    await _notifications.initialize(settings);
    tz.initializeTimeZones();
  }

  static Future<void> scheduleMorningReminder() async {
    const AndroidNotificationDetails androidDetails =
        AndroidNotificationDetails(
      'morning_channel',
      'تذكير أذكار الصباح',
      channelDescription: 'تذكير بأذكار الصباح',
      importance: Importance.high,
      priority: Priority.high,
      icon: '@mipmap/ic_launcher',
    );
    const DarwinNotificationDetails iosDetails =
        DarwinNotificationDetails();
    const NotificationDetails details = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );

    final morningTime = tz.TZDateTime(
      tz.local,
      DateTime.now().year,
      DateTime.now().month,
      DateTime.now().day,
      6, 0, 0,
    );

    await _notifications.zonedSchedule(
      0,
      '🌅 حان وقت أذكار الصباح',
      'ابدأ يومك بذكر الله',
      morningTime,
      details,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }

  static Future<void> scheduleEveningReminder() async {
    const AndroidNotificationDetails androidDetails =
        AndroidNotificationDetails(
      'evening_channel',
      'تذكير أذكار المساء',
      channelDescription: 'تذكير بأذكار المساء',
      importance: Importance.high,
      priority: Priority.high,
      icon: '@mipmap/ic_launcher',
    );
    const DarwinNotificationDetails iosDetails =
        DarwinNotificationDetails();
    const NotificationDetails details = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );

    final eveningTime = tz.TZDateTime(
      tz.local,
      DateTime.now().year,
      DateTime.now().month,
      DateTime.now().day,
      18, 0, 0,
    );

    await _notifications.zonedSchedule(
      1,
      '🌙 حان وقت أذكار المساء',
      'لا تنسَ وردك من الذكر',
      eveningTime,
      details,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }

  static Future<void> scheduleMiddayReminder() async {
    const AndroidNotificationDetails androidDetails =
        AndroidNotificationDetails(
      'midday_channel',
      'تذكير منتصف اليوم',
      channelDescription: 'تذكير بذكر الله في منتصف اليوم',
      importance: Importance.low,
      priority: Priority.low,
      icon: '@mipmap/ic_launcher',
    );
    const DarwinNotificationDetails iosDetails =
        DarwinNotificationDetails();
    const NotificationDetails details = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );

    final middayTime = tz.TZDateTime(
      tz.local,
      DateTime.now().year,
      DateTime.now().month,
      DateTime.now().day,
      12, 0, 0,
    );

    await _notifications.zonedSchedule(
      2,
      '🤲 تذكير منتصف اليوم',
      'ذكر الله يطمئن القلوب',
      middayTime,
      details,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }

  static Future<void> scheduleAllReminders() async {
    await scheduleMorningReminder();
    await scheduleEveningReminder();
    await scheduleMiddayReminder();
  }

  static Future<void> cancelAllReminders() async {
    await _notifications.cancelAll();
  }

  static Future<void> showTestNotification() async {
    const AndroidNotificationDetails androidDetails =
        AndroidNotificationDetails(
      'test_channel',
      'اختبار الإشعارات',
      channelDescription: 'إشعار تجريبي',
      importance: Importance.high,
      priority: Priority.high,
      icon: '@mipmap/ic_launcher',
    );
    const DarwinNotificationDetails iosDetails =
        DarwinNotificationDetails();
    const NotificationDetails details = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );

    await _notifications.show(
      999,
      '📿 Almona',
      'الإشعارات تعمل بنجاح!',
      details,
    );
  }
}
