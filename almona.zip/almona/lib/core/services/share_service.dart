import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import 'package:almona/data/models/adhkar_model.dart';

class ShareService {
  static Future<void> shareDhikr(AdhkarModel adhkar) async {
    final String text = '''
📿 Almona | المنى
${adhkar.arabicText}
${adhkar.englishText}
المصدر: ${adhkar.source}${adhkar.reference != null ? ' (${adhkar.reference})' : ''}
---
شاركها مع من تحب 🤍
تحميل التطبيق: https://almona.app
''';
    
    await Share.share(text);
  }
}
