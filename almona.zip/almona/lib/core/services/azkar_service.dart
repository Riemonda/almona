import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:almona/data/models/adhkar_model.dart';
import 'package:almona/core/network/api_client.dart';
import 'package:almona/core/network/dio_client.dart';

class AzkarService {
  static List<AdhkarModel>? _cachedAzkar;
  static ApiClient? _apiClient;

  static Future<void> init() async {
    final dio = DioClient.create();
    _apiClient = ApiClient(dio);
  }

  static String _formatSurahText(String text, String reference) {
    // سورة الملك
    if (reference.contains('الملك')) {
      return 'سورة الملك\n\nبِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\n\n$text';
    }
    // سورة الدخان
    else if (reference.contains('الدخان')) {
      return 'سورة الدخان\n\nبِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\n\n$text';
    }
    // سورة الإخلاص
    else if (reference.contains('112') || reference.contains('الإخلاص')) {
      return 'سورة الإخلاص\n\nبِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\n\n$text';
    }
    // سورة الفلق
    else if (reference.contains('113') || reference.contains('الفلق')) {
      return 'سورة الفلق\n\nبِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\n\n$text';
    }
    // سورة الناس
    else if (reference.contains('114') || reference.contains('الناس')) {
      return 'سورة الناس\n\nبِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\n\n$text';
    }
    // آية الكرسي
    else if (reference.contains('255') && reference.contains('البقرة')) {
      return 'آية الكرسي\n\n$text';
    }
    // آخر آيتين من البقرة
    else if (reference.contains('285-286')) {
      return 'آخر آيتين من سورة البقرة\n\n$text';
    }
    return text;
  }

  static Future<List<AdhkarModel>> loadAzkar() async {
    try {
      if (_apiClient == null) await init();
      
      final Map<String, dynamic> response = await _apiClient!.getAdhkar();
      
      List<dynamic> dataList = [];
      final results = response['results'];
      if (results is List) {
        dataList = results;
      }
      
      if (dataList.isEmpty) {
        return _loadFromAsset();
      }

      final List<AdhkarModel> azkar = dataList.map((json) {
        String category = 'general';
        final catId = json['category'];
        if (catId == 2) category = 'morning';
        else if (catId == 3) category = 'evening';
        else if (catId == 4) category = 'sleep';
        else if (catId == 5) category = 'travel';
        else if (catId == 6) category = 'prayer';
        
        String arabicText = json['arabic_text'] ?? '';
        String reference = json['reference'] ?? '';
        
        // تطبيق التنسيق
        String formattedText = _formatSurahText(arabicText, reference);
        
        return AdhkarModel(
          id: json['id'] ?? 0,
          category: category,
          arabicText: formattedText,
          englishText: json['english_text'] ?? '',
          repetitions: json['repetitions'] ?? 1,
          source: json['source'] ?? '',
          reference: reference,
          order: json['order'] ?? 0,
          isActive: json['is_active'] ?? true,
        );
      }).toList();
      
      _cachedAzkar = azkar;
      print('✅ تم جلب ${azkar.length} ذكر من API');
      return azkar;
      
    } catch (e) {
      print('⚠️ فشل جلب البيانات من API: $e');
      return _loadFromAsset();
    }
  }

  static Future<List<AdhkarModel>> _loadFromAsset() async {
    try {
      final String response = await rootBundle.loadString('assets/data/hisn_muslim.json');
      final Map<String, dynamic> data = json.decode(response);
      final List<dynamic> azkarList = data['أذكار الصباح والمساء'] ?? [];
      
      List<AdhkarModel> adhkarModels = [];
      for (var item in azkarList) {
        String arabicText = item['ARABIC_TEXT'] ?? '';
        arabicText = arabicText.replaceAll('((', '').replaceAll('))', '');
        int repeat = int.tryParse(item['REPEAT']?.toString() ?? '1') ?? 1;
        int id = int.tryParse(item['ID']?.toString() ?? '0') ?? 0;
        String category = item['CATEGORY'] ?? 'general';
        String englishText = item['ENGLISH'] ?? '';
        String source = item['SOURCE'] ?? 'حصن المسلم';
        String reference = item['REFERENCE'] ?? '';
        
        adhkarModels.add(AdhkarModel(
          id: id,
          category: category,
          arabicText: arabicText,
          englishText: englishText,
          repetitions: repeat,
          source: source,
          reference: reference,
          order: id,
          isActive: true,
        ));
      }
      
      adhkarModels.sort((a, b) => a.id.compareTo(b.id));
      _cachedAzkar = adhkarModels;
      return adhkarModels;
    } catch (e) {
      return _getFallbackAzkar();
    }
  }

  static Future<void> refreshFromApi() async {
    _cachedAzkar = null;
    await loadAzkar();
  }

  static List<AdhkarModel> _getFallbackAzkar() {
    return [
      AdhkarModel(
        id: 1,
        category: 'morning',
        arabicText: 'أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ',
        englishText: 'We have entered the morning and the kingdom belongs to Allah',
        repetitions: 1,
        source: 'صحيح مسلم',
        reference: '2718',
        order: 1,
        isActive: true,
      ),
    ];
  }
}
