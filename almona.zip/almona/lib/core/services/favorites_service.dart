import 'dart:convert';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:almona/data/models/adhkar_model.dart';
import 'package:almona/data/models/favorite_model.dart';

class FavoritesService {
  static Box? _favoritesBox;
  
  static Future<void> init() async {
    _favoritesBox = await Hive.openBox('favorites');
  }
  
  static Box get box {
    if (_favoritesBox == null) {
      throw Exception('Favorites box not initialized. Call init() first.');
    }
    return _favoritesBox!;
  }
  
  static void toggleFavorite(AdhkarModel adhkar) {
    final favorites = getFavorites();
    final existingIndex = favorites.indexWhere((f) => f.id == adhkar.id);
    
    if (existingIndex != -1) {
      // حذف من المفضلة
      final newList = favorites.where((f) => f.id != adhkar.id).toList();
      box.put('favorites_list', jsonEncode(newList.map((f) => f.toJson()).toList()));
    } else {
      // إضافة إلى المفضلة
      final newFavorite = FavoriteModel.fromAdhkar(adhkar);
      final newList = [...favorites, newFavorite];
      box.put('favorites_list', jsonEncode(newList.map((f) => f.toJson()).toList()));
    }
  }
  
  static bool isFavorite(AdhkarModel adhkar) {
    final favorites = getFavorites();
    return favorites.any((f) => f.id == adhkar.id);
  }
  
  static List<FavoriteModel> getFavorites() {
    try {
      final data = box.get('favorites_list');
      if (data == null) return [];
      final List<dynamic> jsonList = jsonDecode(data);
      return jsonList.map((json) => FavoriteModel.fromJson(json)).toList();
    } catch (e) {
      return [];
    }
  }
  
  static void clearFavorites() {
    box.delete('favorites_list');
  }
  
  static int get count => getFavorites().length;
}
