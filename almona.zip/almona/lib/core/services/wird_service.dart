import 'package:hive_flutter/hive_flutter.dart';

class WirdService {
  static Box? _wirdBox;
  
  static Future<void> init() async {
    _wirdBox = await Hive.openBox('wird_status');
  }
  
  static Box get box {
    if (_wirdBox == null) {
      throw Exception('Wird box not initialized. Call init() first.');
    }
    return _wirdBox!;
  }
  
  static void setCategoryComplete(String category, bool complete) {
    box.put('category_$category', complete);
  }
  
  static bool isCategoryComplete(String category) {
    return box.get('category_$category', defaultValue: false);
  }
  
  static void resetAll() {
    box.clear();
  }
}
