import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class AppLocalizations {
  final Locale locale;
  
  AppLocalizations(this.locale);
  
  static AppLocalizations? of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations);
  }
  
  static const LocalizationsDelegate<AppLocalizations> delegate = _AppLocalizationsDelegate();
  
  Map<String, String> _localizedStrings = {};
  
  Future<void> load() async {
    String jsonString = await rootBundle.loadString(
      'assets/translations/${locale.languageCode}.json',
    );
    Map<String, dynamic> jsonMap = json.decode(jsonString);
    _localizedStrings = jsonMap.map((key, value) => MapEntry(key, value.toString()));
  }
  
  String translate(String key) {
    return _localizedStrings[key] ?? key;
  }
  
  // General
  String get appName => translate('app_name');
  String get home => translate('home');
  String get dhikr => translate('dhikr');
  String get search => translate('search');
  String get favorites => translate('favorites');
  String get myWird => translate('my_wird');
  
  // Welcome
  String get welcomeMorning => translate('welcome_morning');
  String get welcomeEvening => translate('welcome_evening');
  String get welcomeNight => translate('welcome_night');
  String get subtitleMorning => translate('subtitle_morning');
  String get subtitleEvening => translate('subtitle_evening');
  String get subtitleNight => translate('subtitle_night');
  
  // Dhikr
  String get now => translate('now');
  String get morningDhikr => translate('morning_dhikr');
  String get eveningDhikr => translate('evening_dhikr');
  String get morningTime => translate('morning_time');
  String get eveningTime => translate('evening_time');
  String get startDhikr => translate('start_dhikr');
  String get dailyWird => translate('daily_wird');
  String get completeWird => translate('complete_wird');
  String get quickDhikr => translate('quick_dhikr');
  
  // Categories
  String get morning => translate('morning');
  String get evening => translate('evening');
  String get sleep => translate('sleep');
  String get afterPrayer => translate('after_prayer');
  String get travel => translate('travel');
  String get all => translate('all');
  String get noDhikr => translate('no_dhikr');
  
  // Favorites
  String get saveFavorites => translate('save_favorites');
  String get addFavorites => translate('add_favorites');
  String get exploreDhikr => translate('explore_dhikr');
  
  // Search
  String get searchDhikr => translate('search_dhikr');
  String get whatLookingFor => translate('what_are_you_looking_for');
  String get searchExample => translate('search_example');
  String get noResults => translate('no_results');
  String get tryOtherWords => translate('try_other_words');
  
  // Stats
  String get stats => translate('stats');
  String get favoritesCount => translate('favorites_count');
  String get totalDhikr => translate('total_dhikr');
  String get streakDays => translate('streak_days');
  String get todayDhikr => translate('today_dhikr');
  String get progress => translate('progress');
  String get from => translate('from');
  String get remaining => translate('remaining');
  String get keepGoing => translate('keep_going');
  String get startJourney => translate('start_journey');
  String get streakMessage => translate('streak_message');
  String get todayIsStart => translate('today_is_start');
  
  // Notifications
  String get notificationMorningTitle => translate('notification_morning_title');
  String get notificationMorningBody => translate('notification_morning_body');
  String get notificationEveningTitle => translate('notification_evening_title');
  String get notificationEveningBody => translate('notification_evening_body');
  String get notificationMiddayTitle => translate('notification_midday_title');
  String get notificationMiddayBody => translate('notification_midday_body');
  String get notificationSettings => translate('notification_settings');
  String get notificationMorning => translate('notification_morning');
  String get notificationEvening => translate('notification_evening');
  String get notificationMidday => translate('notification_midday');
  String get morningReminder => translate('morning_reminder');
  String get eveningReminder => translate('evening_reminder');
  String get middayReminder => translate('midday_reminder');
  
  // Actions
  String get save => translate('save');
  String get cancel => translate('cancel');
  String get delete => translate('delete');
  String get deleteAll => translate('delete_all');
  String get deleteAllConfirm => translate('delete_all_confirm');
  
  // Ayah
  String get ayahOfDay => translate('today_ayah');
  
  // Dhikr detail
  String get dhikrDetail => translate('dhikr_detail');
  String get times => translate('times');
  String get completed => translate('completed');
  String get routine => translate('routine');
  
  // Additional
  String get keepRemembrance => translate('keep_remembrance');
  String get dailyWirdKey => translate('daily_wird_key');
  String get repetition => translate('repetition');
  String get pressToCount => translate('press_to_count');
  String get backToDhikr => translate('back_to_dhikr');
}

class _AppLocalizationsDelegate extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();
  
  @override
  bool isSupported(Locale locale) {
    return ['ar', 'en'].contains(locale.languageCode);
  }
  
  @override
  Future<AppLocalizations> load(Locale locale) async {
    final localizations = AppLocalizations(locale);
    await localizations.load();
    return localizations;
  }
  
  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}
