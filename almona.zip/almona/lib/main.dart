import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:almona/core/theme/app_theme.dart';
import 'package:almona/presentation/screens/splash_screen.dart';
import 'package:almona/core/services/azkar_service.dart';
import 'package:almona/core/services/favorites_service.dart';
import 'package:almona/core/services/wird_service.dart';
import 'package:almona/core/services/notification_service.dart';
import 'package:almona/core/localization/app_localizations.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // =========================================================
  // Hive
  // =========================================================

  try {
    await Hive.initFlutter();

    await Hive.openBox('favorites');
    await Hive.openBox('settings');
  } catch (e, stackTrace) {
    debugPrint('Hive initialization failed: $e');
    debugPrint('$stackTrace');
  }

  // =========================================================
  // Almona services
  // =========================================================

  try {
    await AzkarService.init();
  } catch (e, stackTrace) {
    debugPrint('AzkarService initialization failed: $e');
    debugPrint('$stackTrace');
  }

  try {
    await FavoritesService.init();
  } catch (e, stackTrace) {
    debugPrint('FavoritesService initialization failed: $e');
    debugPrint('$stackTrace');
  }

  try {
    await WirdService.init();
  } catch (e, stackTrace) {
    debugPrint('WirdService initialization failed: $e');
    debugPrint('$stackTrace');
  }

  // =========================================================
  // Notifications
  //
  // Notification errors must NEVER prevent the app from
  // reaching runApp().
  // =========================================================

  try {
    await NotificationService.initialize();
    debugPrint('Notification service initialized successfully.');
  } catch (e, stackTrace) {
    debugPrint('Notification initialization failed: $e');
    debugPrint('$stackTrace');
  }

  try {
    await NotificationService.scheduleAllReminders();
    debugPrint('Notification reminders scheduled successfully.');
  } catch (e, stackTrace) {
    debugPrint('Notification scheduling failed: $e');
    debugPrint('$stackTrace');
  }

  // =========================================================
  // Language
  // =========================================================

  String savedLanguage = 'ar';

  try {
    final settingsBox = Hive.box('settings');

    savedLanguage = settingsBox.get(
      'language',
      defaultValue: 'ar',
    );

    if (savedLanguage != 'ar' && savedLanguage != 'en') {
      savedLanguage = 'ar';
    }
  } catch (e, stackTrace) {
    debugPrint('Failed to read saved language: $e');
    debugPrint('$stackTrace');
  }

  // =========================================================
  // Start Flutter application
  // =========================================================

  runApp(
    AlmonaApp(
      initialLocale: Locale(savedLanguage),
    ),
  );
}

class AlmonaApp extends StatefulWidget {
  final Locale initialLocale;

  const AlmonaApp({
    super.key,
    required this.initialLocale,
  });

  @override
  State<AlmonaApp> createState() => _AlmonaAppState();
}

class _AlmonaAppState extends State<AlmonaApp> {
  late Locale _locale;

  @override
  void initState() {
    super.initState();
    _locale = widget.initialLocale;
  }

  void setLocale(Locale locale) {
    setState(() {
      _locale = locale;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Almona | المنى',

      theme: AppTheme.darkTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: ThemeMode.dark,

      debugShowCheckedModeBanner: false,

      home: SplashScreen(
        onLocaleChange: setLocale,
      ),

      locale: _locale,

      supportedLocales: const [
        Locale('ar', 'SA'),
        Locale('en', 'US'),
      ],

      localizationsDelegates: const [
        AppLocalizations.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
    );
  }
}
