import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:almona/core/theme/app_theme.dart';
import 'package:almona/presentation/screens/splash_screen.dart';
import 'package:almona/core/services/azkar_service.dart';
import 'package:almona/core/services/favorites_service.dart';
import 'package:almona/core/services/wird_service.dart';
import 'package:almona/core/services/notification_service.dart';
import 'package:almona/core/localization/app_localizations.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Hive.initFlutter();
  await Hive.openBox('favorites');
  await Hive.openBox('settings');

  await AzkarService.init();
  await FavoritesService.init();
  await WirdService.init();
  
  await NotificationService.initialize();
  await NotificationService.scheduleAllReminders();

  final settingsBox = await Hive.openBox('settings');
  final String savedLanguage = settingsBox.get('language', defaultValue: 'ar');

  runApp(AlmonaApp(initialLocale: Locale(savedLanguage)));
}

class AlmonaApp extends StatefulWidget {
  final Locale initialLocale;
  const AlmonaApp({super.key, required this.initialLocale});

  @override
  State<AlmonaApp> createState() => _AlmonaAppState();
}

class _AlmonaAppState extends State<AlmonaApp> {
  late Locale _locale;

  @override
  void initState() {
    super.initState();
    _locale = widget.initialLocale;
  }

  void setLocale(Locale locale) {
    setState(() {
      _locale = locale;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Almona | المنى',
      theme: AppTheme.darkTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: ThemeMode.dark,
      debugShowCheckedModeBanner: false,
      home: SplashScreen(onLocaleChange: setLocale),
      locale: _locale,
      supportedLocales: const [Locale('ar', 'SA'), Locale('en', 'US')],
      localizationsDelegates: const [
        AppLocalizations.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
    );
  }
}
